#!/bin/bash

cd verify || exit 1
go mod tidy
go generate ./...
cd .. || exit 1

cd cli || exit 1
go build -o verify-cmsis-example-sdk .
mkdir ../.manpages
./verify-cmsis-example-sdk man >../.manpages/verify-cmsis-example-sdk.1
