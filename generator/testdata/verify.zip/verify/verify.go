package verify

import (
	"context"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	types "github.com/Arm-Debug/cmsis-project-types/project/types"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/config"
)

// ExampleVerifyManager is an implementation of IExampleVerifyManager
// This implementation follows the delegate pattern and so, does not have any business logic.
type ExampleVerifyManager struct {
	cfg      *config.ExampleVerifyManagerConfiguration
	Delegate IExampleVerifyManager
}

/*
Verify function: Verify that a project is valid csolution or uvprojx project

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - project: The project to verify

  - outDir: The directory to output artefacts from the verification (logs and zipped project etc.)

  - projectDir: The root directory of the project

  - boardOverride: An optional board to use to use as the related board for the output project

Return values:

  - ok: Whether the project was verifiable

  - jobName: identifier of the verification job

  - err: Whether the verification step failed
*/
func (imp *ExampleVerifyManager) Verify(ctx context.Context, project *types.Project, outDir string, projectDir string, boardOverride *types.RelatedBoard) (ok bool, jobName string, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.Verify(ctx, project, outDir, projectDir, boardOverride)
}

// GetConfig returns the configuration for ExampleVerify
func (imp *ExampleVerifyManager) GetConfig() *config.ExampleVerifyManagerConfiguration {
	return imp.cfg
}

// NewExampleVerifyWithDelegate returns a new IExampleVerifyManager that uses the delegate implementation provided by d
func NewExampleVerifyWithDelegate(d IExampleVerifyManager) IExampleVerifyManager {
	if d == nil {
		return nil
	}
	return &ExampleVerifyManager{
		cfg:      d.GetConfig(),
		Delegate: d,
	}
}
