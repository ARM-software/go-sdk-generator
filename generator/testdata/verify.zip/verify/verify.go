package verify

import (
	"context"
	"fmt"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/config"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/types"
)

// The implementation of IExampleVerify
type ExampleVerify struct {
	cfg      *config.ExampleVerifyConfiguration
	Delegate IExampleVerify
}

/*
Verify that a project is valid csolution or uvprojx project

Input arguments:

  - ctx: A context to pass into the method. Can be used tocancel long running tasks

  - project: The project to verify

  - outDir: The directory to output artefacts from the verification (logs and zipped project etc.)

  - projectDir: The root directory of the project

Return values:

  - ok: Whether the project was verifiable

  - err: Whether the verification step failed
*/
func (imp *ExampleVerify) Verify(ctx context.Context, project *types.Project, outDir string, projectDir string) (ok bool, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.Verify(ctx, project, outDir, projectDir)
}

// GetConfig returns the configuration for ExampleVerify
func (imp *ExampleVerify) GetConfig() *config.ExampleVerifyConfiguration {
	return imp.cfg
}

// NewExampleVerify returns a new ExampleVerify with the configuration provided by cfg
func NewDefaultExampleVerify(cfg *config.ExampleVerifyConfiguration) *ExampleVerify {
	return &ExampleVerify{
		cfg: cfg,
	}
}

// NewExampleVerifyWithDelegate returns a new IExampleVerify that uses the delegate implementation provided by d
func NewExampleVerifyWithDelegate(d IExampleVerify) IExampleVerify {
	return &ExampleVerify{
		cfg:      d.GetConfig(),
		Delegate: d,
	}
}

/*
Verify that a project is valid csolution or uvprojx project
*/
func Verify(ctx context.Context, logger logs.Loggers, cfg *config.VerifyConfiguration, f func(context.Context, logs.Loggers, *config.VerifyConfiguration) error) (err error) {
	if f == nil {
		err = fmt.Errorf("%w: must provide an implementation of %T to Verify", commonerrors.ErrUndefined, f)
		return
	}

	return f(ctx, logger, cfg)
}
