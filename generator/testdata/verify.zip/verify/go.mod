module github.com/Arm-Debug/verify-cmsis-example-sdk/verify

go 1.24

toolchain go1.24.0

