module github.com/Arm-Debug/verify-cmsis-example-sdk/verify

go 1.22

replace github.com/Arm-Debug/verify-cmsis-example-sdk/verify => ./
