module github.com/Arm-Debug/verify-cmsis-example-sdk/verify

go 1.24

toolchain go1.24.0

tool (
	github.com/dmarkham/enumer
	go.uber.org/mock/mockgen
)