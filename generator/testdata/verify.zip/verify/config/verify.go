package config

import (
	"regexp"
	"time"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
)

// ExampleVerifyManagerConfiguration provides some configuration data object for ExampleVerify
type ExampleVerifyManagerConfiguration struct {
	// APIKey is an API key enabling the use of the online services
	APIKey string `mapstructure:"api_key"`
	// Host is the host to use for accessing the online services
	Host string `mapstructure:"host"`
	// UserAgent is the user agent for the requests
	UserAgent string `mapstructure:"user_agent"`
	// Debug is whether to show debug information during verification
	Debug bool `mapstructure:"debug"`
	// LogError is whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY
	LogError uint32 `mapstructure:"log_error"`
	// Quiet is whether to stream job messages. This will still show logs from the tool itself
	Quiet bool `mapstructure:"quiet"`
	// CleanupOnSuccess is whether to clean up job's records on success
	CleanupOnSuccess bool `mapstructure:"cleanup_on_success"`
	// JobTimeout is timeout to use for waiting for a project to be verified. Important when starting many jobs simultaneously as the service can only handle a limited number at once and jobs may remain in the queue for a while
	JobTimeout time.Duration `mapstructure:"job_timeout"`
}

func (cfg *ExampleVerifyManagerConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.APIKey, validation.Required, validation.Match(regexp.MustCompile(`[a-zA-Z0-9_-]+`))),
		validation.Field(&cfg.Host, validation.Required, is.URL, validation.Match(regexp.MustCompile(`^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?`))),
		validation.Field(&cfg.Debug),
		validation.Field(&cfg.Quiet),
		validation.Field(&cfg.CleanupOnSuccess),
		validation.Field(&cfg.JobTimeout, validation.Required),
	)
}

func DefaultExampleVerifyManagerConfiguration() *ExampleVerifyManagerConfiguration {
	return &ExampleVerifyManagerConfiguration{
		Host:       "https://all.api.keil.arm.com",
		JobTimeout: 5 * time.Minute,
	}
}
