package config

import (
	"regexp"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/types"
)

// Configuration for ExampleVerify
type ExampleVerifyConfiguration struct {
	// An authorisation token for the services
	BearerToken string `mapstructure:"bearer_token"`
	// The host to use for access to the solar services
	Host string `mapstructure:"host"`
	// The user agent for the requests
	UserAgent string `mapstructure:"user_agent"`
	// Whether to show debug information during verification
	Debug bool `mapstructure:"debug"`
	// Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY
	LogError verify.ErrorOutputType `mapstructure:"log_error"`
}

func (cfg *ExampleVerifyConfiguration) Validate() error {
	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.BearerToken, validation.Required, validation.Match(regexp.MustCompile(`[a-zA-Z0-9]+`))),
		validation.Field(&cfg.Host, validation.Required, validation.Match(regexp.MustCompile(`^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?`))),
	)
}

func NewDefaultExampleVerifyConfiguration() *ExampleVerifyConfiguration {
	return &ExampleVerifyConfiguration{}
}

// Configuration for Verify function
type VerifyConfiguration struct {
	// Project configuration
	Project types.Project `mapstructure:"project"`
	// The directory to output artefacts from the verification (logs and zipped project etc.)
	OutDir string `mapstructure:"out_dir"`
	// The root directory of the project
	ProjectDir string `mapstructure:"project_dir"`
	// An authorisation token for the services
	BearerToken string `mapstructure:"bearer_token"`
	// Whether to show debug information during verification
	Debug bool `mapstructure:"debug"`
	// Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY
	LogError verify.ErrorOutputType `mapstructure:"log_error"`
}

func (cfg *VerifyConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,

		validation.Field(&cfg.OutDir, validation.Required),

		validation.Field(&cfg.ProjectDir, validation.Required),

		validation.Field(&cfg.BearerToken, validation.Required, validation.Match(regexp.MustCompile(`[a-zA-Z0-9]+`))),
	)
}

func NewDefaultVerifyConfiguration() *VerifyConfiguration {
	return &VerifyConfiguration{

		Project: *types.DefaultProject(),
	}
}
