package types

import (
	project "github.com/Arm-Debug/solar-pack-project-importer/importer/project"
	validation "github.com/go-ozzo/ozzo-validation"
)

// A project
type Project struct {
	// Path to a project file
	Path string `json:"path" mapstructure:"path"`
	// Name of the project
	Name string `json:"name" mapstructure:"name"`
	// Human readable title for the project
	Title string `json:"title" mapstructure:"title"`
	// The version of the project
	Version string `json:"version" mapstructure:"version"`
	// The description of the project
	Description string `json:"description" mapstructure:"description"`
	// The URL to the documentation for the example
	DocumentationURL string `json:"documentation_url" mapstructure:"documentation_url"`
	// Format of the project (e.g. uvprojx/csolution)
	Format string `json:"format" mapstructure:"format"`
	// Source (URL and type) of the project
	Source project.Origin `json:"source" mapstructure:"source"`
	// Archive information for the project
	Archive project.Archive `json:"archive" mapstructure:"archive"`
	// Is the project convertible to csolution
	Convertible bool `json:"convertible" mapstructure:"convertible"`
	// Requirements (e.g. toolchains) needed for the project
	Requirements project.Requirements `json:"requirements" mapstructure:"requirements"`
	// Keywords for this project
	Keywords []string `json:"keywords" mapstructure:"keywords"`
	// Categories for this project
	Categories []string `json:"categories" mapstructure:"categories"`
	// Unique board ID that this project refers to
	BoardID string `json:"board_id" mapstructure:"board_id"`
	// Pack that contains this project
	RelatedPack string `json:"related_pack" mapstructure:"related_pack"`
}

func (cfg *Project) Validate() error {
	return validation.ValidateStruct(cfg,

		validation.Field(&cfg.Path, validation.Required),
	)
}

func DefaultProject() *Project {
	return &Project{}
}
