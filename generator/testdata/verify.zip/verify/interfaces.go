package verify

import (
	"context"

	types "github.com/Arm-Debug/cmsis-project-types/project/types"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/config"
)

//go:generate go tool mockgen -destination=mocks/mock_$GOPACKAGE.go -package=mocks github.com/Arm-Debug/verify-cmsis-example-sdk/$GOPACKAGE IExampleVerifyManager

// IExampleVerifyManager defines the manager interface: Verify a project is compatible with [CMSIS](https://www.keil.arm.com/cmsis)
type IExampleVerifyManager interface {
	// GetConfig returns the manager's configuration
	GetConfig() *config.ExampleVerifyManagerConfiguration
	/*
		Verify function: Verify that a project is valid csolution or uvprojx project

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * project: The project to verify

		  * outDir: The directory to output artefacts from the verification (logs and zipped project etc.)

		  * projectDir: The root directory of the project

		  * boardOverride: An optional board to use to use as the related board for the output project

		Return values:

		  * ok: Whether the project was verifiable

		  * jobName: identifier of the verification job

		  * err: Whether the verification step failed

	*/
	Verify(ctx context.Context, project *types.Project, outDir string, projectDir string, boardOverride *types.RelatedBoard) (ok bool, jobName string, err error)
}
