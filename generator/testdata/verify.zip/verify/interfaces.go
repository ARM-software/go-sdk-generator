package verify

import (
	"context"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/config"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/types"
)

//go:generate mockgen -destination=mocks/mock_$GOPACKAGE.go -package=mocks github.com/Arm-Debug/verify-cmsis-example-sdk/$GOPACKAGE IExampleVerify

// Verify a project is compatible with cmsis tools
type IExampleVerify interface {
	// GetConfig returns the configuration for ExampleVerifyCLI
	GetConfig() *config.ExampleVerifyConfiguration
	/*
		Verify that a project is valid csolution or uvprojx project

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * project: The project to verify

		  * outDir: The directory to output artefacts from the verification (logs and zipped project etc.)

		  * projectDir: The root directory of the project

		Return values:

		  * ok: Whether the project was verifiable

		  * err: Whether the verification step failed

	*/
	Verify(ctx context.Context, project *types.Project, outDir string, projectDir string) (ok bool, err error)
}
