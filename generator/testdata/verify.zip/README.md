# ExampleVerify SDK

[![Go Badge](https://img.shields.io/badge/go-v1.24.0-blue)](https://golang.org/)

Verify a project is compatible with [CMSIS](https://www.keil.arm.com/cmsis)

> :gear: This project also comes with [CLI tools and commands](./DOCUMENTATION.md#cli_tools) for ease of use

You can access the man page for the CLI via:
```sh
man verify-cmsis-example-sdk
```

## Documentation

To learn more about the SDK and how to use it, please have a look at [our documentation guide](./DOCUMENTATION.md)
