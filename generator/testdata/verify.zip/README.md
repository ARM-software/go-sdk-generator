# ExampleVerify SDK

[![Go Badge](https://img.shields.io/badge/go-v1.24-blue)](https://golang.org/)

Verify a project is compatible with cmsis tools

## Types defined in this package

### `Project`

A project

#### Fields

- **`Path : string`** - Path to a project file (required)

- **`Name : string`** - Name of the project 

- **`Title : string`** - Human readable title for the project 

- **`Version : string`** - The version of the project 

- **`Description : string`** - The description of the project 

- **`DocumentationURL : string`** - The URL to the documentation for the example 

- **`Format : string`** - Format of the project (e.g. uvprojx/csolution) 

- **`Source : project.Origin`** - Source (URL and type) of the project 

- **`Archive : project.Archive`** - Archive information for the project 

- **`Convertible : bool`** - Is the project convertible to csolution 

- **`Requirements : project.Requirements`** - Requirements (e.g. toolchains) needed for the project 

- **`Keywords : []string`** - Keywords for this project 

- **`Categories : []string`** - Categories for this project 

- **`BoardID : string`** - Unique board ID that this project refers to 

- **`RelatedPack : string`** - Pack that contains this project 


### ExampleVerifyConfiguration

ExampleVerifyConfiguration contains configuration that may be useful.

#### Fields

- **`BearerToken : string`** - An authorisation token for the services (required)
  - This field has to follow the pattern `[a-zA-Z0-9]+`

- **`Host : string`** - The host to use for access to the solar services (required)
  - This field has to follow the pattern `^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?`

- **`UserAgent : string`** - The user agent for the requests 
  - This field has to follow the pattern `.+?[/\s][\d.]+`

- **`Debug : bool`** - Whether to show debug information during verification 


- **`LogError : verify.ErrorOutputType`** - Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY 



## Interface defined in this package `IExampleVerify`

Verify that a project is valid csolution or uvprojx project

```go
Verify(project *types.Project, outDir string, projectDir string, extraArgs ...string) (ok bool, err error)
```

Input arguments:

  * `project : types.Project`: The project to verify

  * `outDir : string`: The directory to output artefacts from the verification (logs and zipped project etc.)

  * `projectDir : string`: The root directory of the project

  * `extraArgs : ...string`: A set of extra arguments for the job

Return values:

  * `ok : bool`: Whether the project was verifiable

  * `err : error`: Whether the verification step failed

# ExampleVerify CLI Usage

CLI for verifying an individual example is compatible with cmsis tools

## Functions

### Verify

Verify that a project is valid csolution or uvprojx project

```go
func(ctx context.Context, logger logs.Loggers, cfg config.VerifyConfiguration)
```

#### `config.VerifyConfiguration`

```go
type VerifyConfiguration struct {
	// Project configuration
		Project types.Project `mapstructure:"project"`
	// The directory to output artefacts from the verification (logs and zipped project etc.)
		OutDir string `mapstructure:"out_dir"`
	// The root directory of the project
		ProjectDir string `mapstructure:"project_dir"`
	// An authorisation token for the services
		BearerToken string `mapstructure:"bearer_token"`
	// Whether to show debug information during verification
		Debug bool `mapstructure:"debug"`
	// Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY
		LogError verify.ErrorOutputType `mapstructure:"log_error"`
	
}
```

Functions to utilise this configuration are also provided:

The `Validate()` function can be used to validate that all fields have been provided:

```go
func (cfg *VerifyConfiguration) Validate() error
```

The `NewDefaultVerifyConfiguration()` function can be used to provide default values to the configuration:

```go
func NewDefaultVerifyConfiguration() *VerifyConfiguration
```

