package main

import "github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd"

func main() {
	cmd.Execute()
}
