// Package cmd defines all the CLI commands for ExampleVerify
package cmd

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/field"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/spf13/cobra"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/config"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/verify"
)

const (
	verifyOutDirArg     = "out-dir"
	verifyProjectDirArg = "project-dir"

	verifyHostArg = "host"

	verifyNameArg     = "override-board-name"
	verifyVendorArg   = "override-board-vendor"
	verifyRevisionArg = "override-board-revision"

	verifyOverrideBoardReferenceArg = "override-board-reference"
)

func addInterruptHandlerToContext(ctx context.Context) (cancellableCtx context.Context, cancel context.CancelFunc) {
	cancellableCtx, cancel = context.WithCancel(ctx)
	end := make(chan error, 1)
	go func() {
		// Waits for a user interrupt or SIGTERM or expired/cancelled context
		shutdown := make(chan os.Signal, 1)
		signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
		for wait := true; wait; {
			select {
			case <-shutdown:
				wait = false
			case <-ctx.Done():
				wait = false
			}
		}

		cancel()
		close(end)
	}()
	return
}

var verifyCmd = &cobra.Command{
	Use:   "verify",
	Short: "Verify that a project is valid csolution or uvprojx project",
	Long:  "Verify that a project is valid csolution or uvprojx project",
	Run: func(cmd *cobra.Command, args []string) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Verify")
		if err != nil {
			fmt.Printf("failed initialising the logger: %v\n", err.Error())
			os.Exit(1)
		}

		var verifyCfg config.VerifyConfiguration

		err = configUtils.LoadFromViper(viperSession, app, &verifyCfg, config.DefaultVerifyConfiguration())
		if err != nil {
			logger.LogError(err, "failed initialising verify command")
			os.Exit(1)
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			verifyCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}

		err = verify.WrapVerify(cancellableCtx, logger, &verifyCfg, verify.VerifyImplFunc)
		if err != nil {
			logger.LogError(err)
			cancel()
			os.Exit(1)
		}
	},
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Prints tool's version",
	Long:  "Prints tool's version in standard output (StdOut). The version follows SemVer.",
	Run: func(cmd *cobra.Command, args []string) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Version")
		if err != nil {
			fmt.Printf("failed initialising the logger: %v\n", err.Error())
			os.Exit(1)
		}
		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		version, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err != nil {
			logger.LogError(err)
			cancel()
			os.Exit(1)
		}
		fmt.Println(version)
	},
}

func init() {
	rootCmd.AddCommand(versionCmd)

	verifyCmd.Flags().String(verifyOutDirArg, "", "The directory to output artefacts from the verification (logs and zipped project etc.)")
	_ = configUtils.BindFlagToEnv(viperSession, app, "out_dir", verifyCmd.Flags().Lookup(verifyOutDirArg))

	verifyCmd.Flags().String(verifyProjectDirArg, "", "The root directory of the project")
	_ = configUtils.BindFlagToEnv(viperSession, app, "project_dir", verifyCmd.Flags().Lookup(verifyProjectDirArg))

	verifyCmd.Flags().String(verifyHostArg, "", "The host to use for accessing the online services")
	_ = configUtils.BindFlagToEnv(viperSession, app, "host", verifyCmd.Flags().Lookup(verifyHostArg))

	verifyCmd.Flags().String(verifyNameArg, "", "Name of the override board")
	_ = configUtils.BindFlagToEnv(viperSession, app, "override_board_name", verifyCmd.Flags().Lookup(verifyNameArg))
	verifyCmd.Flags().String(verifyVendorArg, "", "Vendor of the override board")
	_ = configUtils.BindFlagToEnv(viperSession, app, "override_board_vendor", verifyCmd.Flags().Lookup(verifyVendorArg))
	verifyCmd.Flags().String(verifyRevisionArg, "", "Revision of the override board")
	_ = configUtils.BindFlagToEnv(viperSession, app, "override_board_revision", verifyCmd.Flags().Lookup(verifyRevisionArg))

	verifyCmd.Flags().String(verifyOverrideBoardReferenceArg, "", "An optional board reference to use")
	_ = configUtils.BindFlagToEnv(viperSession, app, "override_board_reference", verifyCmd.Flags().Lookup(verifyOverrideBoardReferenceArg))

	rootCmd.AddCommand(verifyCmd)

}
