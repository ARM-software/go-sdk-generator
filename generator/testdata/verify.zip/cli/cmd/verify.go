package cmd

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/spf13/cobra"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/verify/config"
)

const (
	verifyOutDirArg     = "out-dir"
	verifyProjectDirArg = "project-dir"
)

func addInterruptHandlerToContext(ctx context.Context) (cancellableCtx context.Context, cancel context.CancelFunc) {
	cancellableCtx, cancel = context.WithCancel(ctx)
	end := make(chan error, 1)
	go func() {
		// Waits for a user interrupt or SIGTERM or expired/cancelled context
		shutdown := make(chan os.Signal, 1)
		signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
		for wait := true; wait; {
			select {
			case <-shutdown:
				wait = false
			case <-ctx.Done():
				wait = false
			}
		}

		cancel()
		close(end)
	}()
	return
}

var verifyCfg config.VerifyConfiguration

var verifyFunc func(context.Context, logs.Loggers, *config.VerifyConfiguration) error = nil

var verifyCmd = &cobra.Command{
	Use:   "verify",
	Short: "Verify that a project is valid csolution or uvprojx project",
	Long:  "Verify that a project is valid csolution or uvprojx project",
	Run: func(cmd *cobra.Command, args []string) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Verify")
		if err != nil {
			fmt.Printf("failed initialising the logger: %v\n", err.Error())
			os.Exit(1)
		}

		err = configUtils.LoadFromViper(viperSession, app, &verifyCfg, config.DefaultVerifyConfiguration())
		if err != nil {
			logger.LogError(err, "failed initialising verify command")
			os.Exit(1)
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		err = verify.Verify(cancellableCtx, logger, &verifyCfg, verifyFunc)
		if err != nil {
			logger.LogError(err)
			cancel()
			os.Exit(1)
		}
	},
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Prints tool's version",
	Long:  "Prints tool's version in standard output (StdOut). The version follows SemVer.",
	Run: func(cmd *cobra.Command, args []string) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Version")
		if err != nil {
			fmt.Printf("failed initialising the logger: %v\n", err.Error())
			os.Exit(1)
		}
		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		version, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err != nil {
			logger.LogError(err)
			cancel()
			os.Exit(1)
		}
		fmt.Println(version)
	},
}

func init() {
	rootCmd.AddCommand(versionCmd)
	verifyCmd.Flags().String(verifyOutDirArg, "", "The directory to output artefacts from the verification (logs and zipped project etc.)")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_out_dir", app), verifyCmd.Flags().Lookup(verifyOutDirArg))
	verifyCmd.Flags().String(verifyProjectDirArg, "", "The root directory of the project")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_project_dir", app), verifyCmd.Flags().Lookup(verifyProjectDirArg))

	rootCmd.AddCommand(verifyCmd)

}
