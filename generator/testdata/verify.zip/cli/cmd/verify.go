// Package cmd defines all the CLI commands for ExampleVerify
package cmd

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/field"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/spf13/cobra"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/config"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/verify"
)

const (
	verifyNoKeyringArg              = "no-keyring" //nolint:gosec // not a secret
	verifyOutDirArg                 = "out-dir"
	verifyOverrideBoardNameArg      = "override-board-name"
	verifyOverrideBoardReferenceArg = "override-board-reference"
	verifyOverrideBoardRevisionArg  = "override-board-revision"
	verifyOverrideBoardVendorArg    = "override-board-vendor"
	verifyProjectDirArg             = "project-dir"
)

func addInterruptHandlerToContext(ctx context.Context) (cancellableCtx context.Context, cancel context.CancelCauseFunc) {
	var cause error
	cancellableCtx, cancel = context.WithCancelCause(ctx)
	end := make(chan error, 1)
	go func() {
		// Waits for a user interrupt or SIGTERM or expired/cancelled context
		shutdown := make(chan os.Signal, 1)
		signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
		for wait := true; wait; {
			select {
			case s := <-shutdown:
				cause = commonerrors.Newf(commonerrors.ErrInterrupted, "received signal '%v'", s)
				wait = false
			case <-ctx.Done():
				wait = false
			}
		}

		cancel(cause)
		close(end)
	}()
	return
}

var verifyCmd = &cobra.Command{
	Use:   "verify",
	Short: "Verify that a project is valid csolution or uvprojx project",
	Long:  "Verify that a project is valid csolution or uvprojx project",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Verify")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var verifyCfg config.VerifyConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultVerifyConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		cfgLoadOptions = append(cfgLoadOptions, configUtils.WithKeyring(!cmd.Flags().Changed(verifyNoKeyringArg)))
		err = configUtils.LoadUsing(&verifyCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			verifyCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}
		err = verify.WrapVerify(cancellableCtx, logger, &verifyCfg, verify.VerifyImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		return
	},
	SilenceUsage: true, // otherwise 'Usage' is printed after any error
	Hidden:       true,
}

func init() {
	verifyCmd.Flags().Bool(verifyNoKeyringArg, false, "Disable loading configuration from the system keyring")
	verifyCmd.Flags().String(verifyOutDirArg, "", "The directory to output artefacts from the verification (logs and zipped project etc.)")
	verifyCmd.Flags().String(verifyOverrideBoardNameArg, "", "Name of the override board")
	verifyCmd.Flags().String(verifyOverrideBoardVendorArg, "", "Vendor of the override board")
	verifyCmd.Flags().String(verifyOverrideBoardRevisionArg, "", "Revision of the override board")
	verifyCmd.Flags().String(verifyOverrideBoardReferenceArg, "", "An optional board reference to use")
	verifyCmd.Flags().StringP(verifyProjectDirArg, "d", "", "The root directory of the project")

	_ = configUtils.BindFlagToEnv(viperSession, config.App, "no_keyring", verifyCmd.Flags().Lookup(verifyNoKeyringArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "out_dir", verifyCmd.Flags().Lookup(verifyOutDirArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_name", verifyCmd.Flags().Lookup(verifyOverrideBoardNameArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_reference", verifyCmd.Flags().Lookup(verifyOverrideBoardReferenceArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_revision", verifyCmd.Flags().Lookup(verifyOverrideBoardRevisionArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_vendor", verifyCmd.Flags().Lookup(verifyOverrideBoardVendorArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "project_dir", verifyCmd.Flags().Lookup(verifyProjectDirArg))

	rootCmd.AddCommand(verifyCmd)
}
