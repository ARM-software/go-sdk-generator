// Package cmd defines all the CLI commands for ExampleVerify
package cmd

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/field"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/spf13/cobra"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/config"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/verify"
)

const (
	verifyHostArg                   = "host"
	verifyOutDirArg                 = "out-dir"
	verifyOverrideBoardNameArg      = "override-board-name"
	verifyOverrideBoardReferenceArg = "override-board-reference"
	verifyOverrideBoardRevisionArg  = "override-board-revision"
	verifyOverrideBoardVendorArg    = "override-board-vendor"
	verifyProjectDirArg             = "project-dir"
)

func addInterruptHandlerToContext(ctx context.Context) (cancellableCtx context.Context, cancel context.CancelCauseFunc) {
	var cause error
	cancellableCtx, cancel = context.WithCancelCause(ctx)
	end := make(chan error, 1)
	go func() {
		// Waits for a user interrupt or SIGTERM or expired/cancelled context
		shutdown := make(chan os.Signal, 1)
		signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
		for wait := true; wait; {
			select {
			case s := <-shutdown:
				cause = commonerrors.Newf(commonerrors.ErrInterrupted, "received signal '%v'", s)
				wait = false
			case <-ctx.Done():
				wait = false
			}
		}

		cancel(cause)
		close(end)
	}()
	return
}

var verifyCmd = &cobra.Command{
	Use:   "verify",
	Short: "Verify that a project is valid csolution or uvprojx project",
	Long:  "Verify that a project is valid csolution or uvprojx project",
	RunE: func(cmd *cobra.Command, args []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Verify")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var verifyCfg config.VerifyConfiguration

		err = configUtils.LoadFromViper(viperSession, config.App, &verifyCfg, config.DefaultVerifyConfiguration())
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			verifyCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}

		err = verify.WrapVerify(cancellableCtx, logger, &verifyCfg, verify.VerifyImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		return
	},
}

func init() {
	verifyCmd.Flags().String(verifyOutDirArg, "", "The directory to output artefacts from the verification (logs and zipped project etc.)")
	verifyCmd.Flags().StringP(verifyProjectDirArg, "d", "", "The root directory of the project")
	verifyCmd.Flags().String(verifyHostArg, "", "The host to use for accessing the online services")
	verifyCmd.Flags().String(verifyOverrideBoardNameArg, "", "Name of the override board")
	verifyCmd.Flags().String(verifyOverrideBoardVendorArg, "", "Vendor of the override board")
	verifyCmd.Flags().String(verifyOverrideBoardRevisionArg, "", "Revision of the override board")
	verifyCmd.Flags().String(verifyOverrideBoardReferenceArg, "", "An optional board reference to use")

	_ = configUtils.BindFlagToEnv(viperSession, config.App, "host", verifyCmd.Flags().Lookup(verifyHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "out_dir", verifyCmd.Flags().Lookup(verifyOutDirArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_name", verifyCmd.Flags().Lookup(verifyOverrideBoardNameArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_reference", verifyCmd.Flags().Lookup(verifyOverrideBoardReferenceArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_revision", verifyCmd.Flags().Lookup(verifyOverrideBoardRevisionArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "override_board_vendor", verifyCmd.Flags().Lookup(verifyOverrideBoardVendorArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "project_dir", verifyCmd.Flags().Lookup(verifyProjectDirArg))

	rootCmd.AddCommand(verifyCmd)
}
