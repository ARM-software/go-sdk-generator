package cmd

import (
	"fmt"
	"os"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

const (
	app                = "VERIFY_EXAMPLE"
	rootPathArg        = "project-path"
	rootBearerTokenArg = "bearer-token"
	rootDebugArg       = "debug"
	rootLogErrorArg    = "log-error"
)

var (
	viperSession = viper.New()
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "verify-example",
	Short: "CLI for verifying an individual example is compatible with cmsis tools",
	Long:  "CLI for verifying an individual example is compatible with cmsis tools",
}

func Execute() {
	err := rootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}

func init() {
	rootCmd.PersistentFlags().String(rootPathArg, "", "path to a project file within the project directory")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_project_path", app), rootCmd.PersistentFlags().Lookup(rootPathArg))
	rootCmd.PersistentFlags().String(rootBearerTokenArg, "", "An authorisation token for the services")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_bearer_token", app), rootCmd.PersistentFlags().Lookup(rootBearerTokenArg))
	rootCmd.PersistentFlags().Bool(rootDebugArg, false, "Whether to show debug information during verification")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_debug", app), rootCmd.PersistentFlags().Lookup(rootDebugArg))
	rootCmd.PersistentFlags().Verify.ErrorOutputType(rootLogErrorArg, nil, "Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_log_error", app), rootCmd.PersistentFlags().Lookup(rootLogErrorArg))

}
