package cmd

import (
	"context"
	"embed"
	"os"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/charmbracelet/fang"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"

	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/config"
)

const (
	rootAPIKeyArg           = "api-key" //nolint:gosec // not a secret
	rootCleanUpOnSuccessArg = "cleanup"
	rootDebugArg            = "debug"
	rootHiddenFlagArg       = "hidden"
	rootHostArg             = "host"
	rootJobTimeoutArg       = "job-timeout"
	rootLogErrorArg         = "log-error"
	rootPathArg             = "path"
	rootQuietArg            = "quiet"
)

var (
	//go:embed module.properties
	embeddedFS   embed.FS
	viperSession = viper.New()
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "verify-cmsis-example-sdk",
	Short: "CLI for verifying an individual example is compatible with cmsis tools",
	Long:  "CLI for verifying an individual example is compatible with cmsis tools",
}

func Execute() {
	ctx := context.Background()

	cliVersion, err := semver.DetermineEmbeddedVersion(ctx, &embeddedFS, nil)
	if err != nil {
		// This is for completeness but it is impossible at runtime since we need a valid module.properties in this location to release the package
		cliVersion = "unknown"
	}

	if err := fang.Execute(ctx, rootCmd, fang.WithVersion(cliVersion)); err != nil {

		if commonerrors.Any(err, commonerrors.ErrInterrupted) {
			os.Exit(45)
		}

		os.Exit(1)
	}
}

func init() {
	rootCmd.PersistentFlags().StringP(rootAPIKeyArg, "k", "", "An API key enabling the use of the online services")
	rootCmd.PersistentFlags().Bool(rootCleanUpOnSuccessArg, false, "Whether to clean up job records on success.")
	rootCmd.PersistentFlags().Bool(rootDebugArg, false, "Whether to show debug information and save intermediate artifacts during verification")
	rootCmd.PersistentFlags().Bool(rootHiddenFlagArg, false, "I am a hidden flag")
	rootCmd.PersistentFlags().MarkHidden(rootHiddenFlagArg)
	rootCmd.PersistentFlags().String(rootHostArg, "", "The host to use for accessing the online services")
	rootCmd.PersistentFlags().Duration(rootJobTimeoutArg, 0, "Timeout to use for waiting for a project to be verified. Important when starting many jobs simultaneously as the service can only handle a limited number at once and jobs may remain in the queue for a while")
	rootCmd.PersistentFlags().Int(rootLogErrorArg, 0, "Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY")
	rootCmd.PersistentFlags().StringP(rootPathArg, "p", "", "Project configuration")
	rootCmd.PersistentFlags().Bool(rootQuietArg, false, "Whether to stream job messages. This will still show logs from the tool itself")

	_ = configUtils.BindFlagToEnv(viperSession, config.App, "api_key", rootCmd.PersistentFlags().Lookup(rootAPIKeyArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "cleanup", rootCmd.PersistentFlags().Lookup(rootCleanUpOnSuccessArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "debug", rootCmd.PersistentFlags().Lookup(rootDebugArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "hidden", rootCmd.PersistentFlags().Lookup(rootHiddenFlagArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "host", rootCmd.PersistentFlags().Lookup(rootHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "job_timeout", rootCmd.PersistentFlags().Lookup(rootJobTimeoutArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "log_error", rootCmd.PersistentFlags().Lookup(rootLogErrorArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "path", rootCmd.PersistentFlags().Lookup(rootPathArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "quiet", rootCmd.PersistentFlags().Lookup(rootQuietArg))
}
