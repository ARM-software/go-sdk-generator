package cmd

import (
	"context"
	"embed"
	"fmt"
	"os"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/charmbracelet/fang"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

const (
	app = "VERIFY_EXAMPLE"

	rootPathArg = "project-path"

	rootAPIKeyArg = "api-key" //nolint:gosec // not a secret

	rootDebugArg            = "debug"
	rootLogErrorArg         = "log-error"
	rootQuietArg            = "quiet"
	rootCleanUpOnSuccessArg = "cleanup"
	rootJobTimeoutArg       = "job-timeout"
)

var (
	//go:embed module.properties
	embeddedFS   embed.FS
	viperSession = viper.New()
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "verify-cmsis-example-sdk",
	Short: "CLI for verifying an individual example is compatible with cmsis tools",
	Long:  "CLI for verifying an individual example is compatible with cmsis tools",
}

func Execute() {
	ctx := context.Background()

	cliVersion, err := semver.DetermineEmbeddedVersion(ctx, &embeddedFS, nil)
	if err != nil {
		// This is for completeness but it is impossible at runtime since we need a valid module.properties in this location to release the package
		cliVersion = "unknown"
	}

	if err := fang.Execute(ctx, rootCmd, fang.WithVersion(cliVersion)); err != nil {
		os.Exit(1)
	}
}

func init() {

	rootCmd.PersistentFlags().String(rootPathArg, "", "path to a project file within the project directory")
	_ = configUtils.BindFlagToEnv(viperSession, app, fmt.Sprintf("%s_project_path", app), rootCmd.PersistentFlags().Lookup(rootPathArg))

	rootCmd.PersistentFlags().String(rootAPIKeyArg, "", "An API key enabling the use of the online services")
	_ = configUtils.BindFlagToEnv(viperSession, app, "api_key", rootCmd.PersistentFlags().Lookup(rootAPIKeyArg))

	rootCmd.PersistentFlags().Bool(rootDebugArg, false, "Whether to show debug information and save intermediate artifacts during verification")
	_ = configUtils.BindFlagToEnv(viperSession, app, "debug", rootCmd.PersistentFlags().Lookup(rootDebugArg))

	rootCmd.PersistentFlags().Int(rootLogErrorArg, 0, "Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY")
	_ = configUtils.BindFlagToEnv(viperSession, app, "log_error", rootCmd.PersistentFlags().Lookup(rootLogErrorArg))

	rootCmd.PersistentFlags().Bool(rootQuietArg, false, "Whether to stream job messages. This will still show logs from the tool itself")
	_ = configUtils.BindFlagToEnv(viperSession, app, "quiet", rootCmd.PersistentFlags().Lookup(rootQuietArg))

	rootCmd.PersistentFlags().Bool(rootCleanUpOnSuccessArg, false, "Whether to clean up job records on success.")
	_ = configUtils.BindFlagToEnv(viperSession, app, "cleanup", rootCmd.PersistentFlags().Lookup(rootCleanUpOnSuccessArg))

	rootCmd.PersistentFlags().Duration(rootJobTimeoutArg, 0, "Timeout to use for waiting for a project to be verified. Important when starting many jobs simultaneously as the service can only handle a limited number at once and jobs may remain in the queue for a while")
	_ = configUtils.BindFlagToEnv(viperSession, app, "job_timeout", rootCmd.PersistentFlags().Lookup(rootJobTimeoutArg))

}
