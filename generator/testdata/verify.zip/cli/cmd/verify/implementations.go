package verify

import (
	"context"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/config"
)

/*
Verify function: Verify that a project is valid csolution or uvprojx project
*/
func Verify(ctx context.Context, logger logs.Loggers, cfg *config.VerifyConfiguration) (err error) {

	// TODO implement me
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Verify()` implementation")
}

func init() {
	// TODO uncomment when implemented
	//  VerifyImplFunc = Verify
}
