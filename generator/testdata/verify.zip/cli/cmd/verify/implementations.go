// Package verify contains the implementation for all the CLI commands.
// Importing the package also performs the automatic binding between the definition and the implementation.
package verify

import (
	"context"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/Arm-Debug/verify-cmsis-example-sdk/cli/cmd/config"
)

/*
Verify function: Verify that a project is valid csolution or uvprojx project
*/
func Verify(ctx context.Context, logger logs.Loggers, cfg *config.VerifyConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. verify.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Verify()` implementation")
}

func init() {
	// Note: The following makes the link between the CLI command definitions and their actual implementations.
	// The binding is performed at runtime when package verify is imported.
	// TODO uncomment when implemented
	//  VerifyImplFunc = Verify
}
