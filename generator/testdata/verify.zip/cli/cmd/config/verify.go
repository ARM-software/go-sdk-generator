package config

import (
	"regexp"
	"time"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"

	types "github.com/Arm-Debug/cmsis-project-types/project/types"
)

const (
	App = "VERIFY_EXAMPLE"
)

// VerifyConfiguration defines the configuration for Verify command
type VerifyConfiguration struct {
	// An API key enabling the use of the online services
	APIKey string `mapstructure:"api_key"`
	// Whether to clean up job records on success.
	CleanUpOnSuccess bool `mapstructure:"cleanup"`
	// Whether to show debug information and save intermediate artifacts during verification
	Debug bool `mapstructure:"debug"`
	// I am a hidden flag
	HiddenFlag bool `mapstructure:"hidden"`
	// The host to use for accessing the online services
	Host string `mapstructure:"host"`
	// Timeout to use for waiting for a project to be verified. Important when starting many jobs simultaneously as the service can only handle a limited number at once and jobs may remain in the queue for a while
	JobTimeout time.Duration `mapstructure:"job_timeout"`
	// Whether to log the errors at the end of a job. 0 for no, 1 for printing to stdout, 2 for printing to GITHUB_SUMMARY
	LogError int `mapstructure:"log_error"`
	// The directory to output artefacts from the verification (logs and zipped project etc.)
	OutDir string `mapstructure:"out_dir"`
	// An optional board override to use instead of parsing it from the project itself
	OverrideBoard types.BoardID `mapstructure:"override_board"`
	// An optional board reference to use
	OverrideBoardReference string `mapstructure:"override_board_reference"`
	// Project configuration
	Project types.Project `mapstructure:"project"`
	// The root directory of the project
	ProjectDir string `mapstructure:"project_dir"`
	// Whether to stream job messages. This will still show logs from the tool itself
	Quiet bool `mapstructure:"quiet"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *VerifyConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.APIKey, validation.Required, validation.Match(regexp.MustCompile(`^(?!.*\s)[!-~]+$`))),
		validation.Field(&cfg.CleanUpOnSuccess),
		validation.Field(&cfg.Debug),
		validation.Field(&cfg.HiddenFlag),
		validation.Field(&cfg.Host, validation.Required, is.URL),
		validation.Field(&cfg.OutDir, validation.Required),
		validation.Field(&cfg.ProjectDir, validation.Required),
		validation.Field(&cfg.Quiet),
	)
}

func DefaultVerifyConfiguration() *VerifyConfiguration {
	return &VerifyConfiguration{

		Host: "https://all.api.keil.arm.com",

		JobTimeout: func() time.Duration {
			duration, _ := time.ParseDuration("5m")
			return duration
		}(),

		OverrideBoard: types.BoardID{},

		Project: *types.DefaultProject(),
	}
}
