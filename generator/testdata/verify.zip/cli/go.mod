module github.com/Arm-Debug/verify-cmsis-example-sdk/cli

go 1.22

replace github.com/Arm-Debug/verify-cmsis-example-sdk/verify => ../verify

