module github.com/Arm-Debug/verify-cmsis-example-sdk/cli

go 1.24.4

toolchain go1.24.4

replace github.com/Arm-Debug/verify-cmsis-example-sdk/verify => ../verify

