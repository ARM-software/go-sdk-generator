package types

import (
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"

	project "github.com/Arm-Debug/solar-pack-project-importer/importer/project"
)

// Project represents a project
type Project struct {
	// Path is path to a project file
	Path string `json:"path" mapstructure:"path"`
	// Name is name of the project
	Name string `json:"name" mapstructure:"name"`
	// Title is human readable title for the project
	Title string `json:"title" mapstructure:"title"`
	// Version is the version of the project
	Version string `json:"version" mapstructure:"version"`
	// Description is the description of the project
	Description string `json:"description" mapstructure:"description"`
	// DocumentationURL is the URL to the documentation for the example
	DocumentationURL string `json:"documentation_url" mapstructure:"documentation_url"`
	// Format is format of the project (e.g. uvprojx/csolution)
	Format string `json:"format" mapstructure:"format"`
	// Source is source (URL and type) of the project
	Source project.Origin `json:"source" mapstructure:"source"`
	// Archive is archive information for the project
	Archive project.Archive `json:"archive" mapstructure:"archive"`
	// Convertible is is the project convertible to csolution
	Convertible bool `json:"convertible" mapstructure:"convertible"`
	// Requirements is requirements (e.g. toolchains) needed for the project
	Requirements project.Requirements `json:"requirements" mapstructure:"requirements"`
	// Keywords is keywords for this project
	Keywords []string `json:"keywords" mapstructure:"keywords"`
	// Categories is categories for this project
	Categories []string `json:"categories" mapstructure:"categories"`
	// BoardID is unique board ID that this project refers to
	BoardID string `json:"board_id" mapstructure:"board_id"`
	// RelatedPack is pack that contains this project
	RelatedPack string `json:"related_pack" mapstructure:"related_pack"`
}

func (cfg *Project) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,

		validation.Field(&cfg.Path, validation.Required),

		validation.Field(&cfg.Version, is.Semver),

		validation.Field(&cfg.DocumentationURL, is.URL),

		validation.Field(&cfg.Convertible),

		validation.Field(&cfg.BoardID, is.UUID),
	)
}

func DefaultProject() *Project {
	return &Project{}
}
