module github.com/Arm-Debug/workspace-service-sdk/workspace

go 1.24.0

toolchain go1.24.0

tool (
	github.com/dmarkham/enumer
	go.uber.org/mock/mockgen
)