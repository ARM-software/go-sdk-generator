module github.com/Arm-Debug/workspace-service-sdk/workspace

go 1.22

replace github.com/Arm-Debug/workspace-service-sdk/workspace => ./
