module github.com/Arm-Debug/workspace-service-sdk/workspace

go 1.24

toolchain go1.24.0

