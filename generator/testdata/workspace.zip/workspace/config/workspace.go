package config

import (
	"regexp"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
)

// WorkspaceManagerConfiguration provides some configuration data object for Workspace
type WorkspaceManagerConfiguration struct {
	// BearerToken is an authorisation token for the services
	BearerToken string `mapstructure:"bearer_token"`
}

func (cfg *WorkspaceManagerConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.BearerToken, validation.Required, validation.Match(regexp.MustCompile(`[a-z]+`))),
	)
}

func DefaultWorkspaceManagerConfiguration() *WorkspaceManagerConfiguration {
	return &WorkspaceManagerConfiguration{}
}
