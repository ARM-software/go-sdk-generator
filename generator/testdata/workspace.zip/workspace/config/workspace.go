package config

import (
	"regexp"

	validation "github.com/go-ozzo/ozzo-validation/v4"
)

// Configuration for Workspace
type WorkspaceConfiguration struct {
	// An authorisation token for the services
	BearerToken string `mapstructure:"bearer_token"`
}

func (cfg *WorkspaceConfiguration) Validate() error {
	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.BearerToken, validation.Required, validation.Match(regexp.MustCompile(`[a-z]+`))),
	)
}

func DefaultWorkspaceConfiguration() *WorkspaceConfiguration {
	return &WorkspaceConfiguration{}
}
