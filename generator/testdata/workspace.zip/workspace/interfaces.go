package workspace

import (
	"context"

	client "github.com/ARM-software/embedded-development-services-client/client"
	"github.com/Arm-Debug/workspace-service-sdk/workspace/config"
	_ "github.com/golang/mock/gomock"
)

//go:generate mockgen -destination=mocks/mock_$GOPACKAGE.go -package=mocks github.com/Arm-Debug/workspace-service-sdk/$GOPACKAGE IWorkspace

// Create and manipulate workspaces
type IWorkspace interface {
	// GetConfig returns the configuration for WorkspaceCLI
	GetConfig() *config.WorkspaceConfiguration
	/*
		Set the workspace name

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * name: The workspace name

		Return values:

		  * err: Whether the fetch failed

	*/
	SetWorkspaceName(ctx context.Context, name string) (err error)
	/*
		Get the workspace name

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		Return values:

		  * name: The workspace name

		  * err: Whether the fetch failed

	*/
	GetWorkspaceName(ctx context.Context) (name *string, err error)
	/*
		Create a workspace

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * name: The workspace name

		  * sourceName: The workspace source type (git/zip)

		Return values:

		  * item: The workspace item

		  * err: Whether the creation failed

	*/
	CreateWorkspace(ctx context.Context, name string, sourceName string) (item *client.WorkspaceItem, err error)
	/*
		Retain a workspace

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * name: The workspace name

		Return values:

		  * item: The workspace item

		  * err: Whether the retain failed

	*/
	RetainWorkspace(ctx context.Context, name string) (item *client.WorkspaceItem, err error)
	/*
		List workspaces

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		Return values:

		  * collection: The collection of workspaces

		  * err: Whether the list failed

	*/
	ListWorkspaces(ctx context.Context) (collection *client.WorkspaceCollection, err error)
	/*
		Get the ETAG for a workspace source of type zip

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * name: The workspace name

		Return values:

		  * etag: The etag for the zip source

		  * err: Whether the etag fetch failed

	*/
	GetWorkspaceZipSourceEtag(ctx context.Context, name string) (etag string, err error)
	/*
		Upload content to a workspace

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * artefact: The artefact to upload

		Return values:

		  * err: Whether the upload failed

	*/
	UploadWorkspaceContent(ctx context.Context, artefact string) (err error)
	/*
		Fetch content from a git repository

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * url: Repository URL

		  * ref: Repository reference

		Return values:

		  * err: Whether the fetch failed

	*/
	FetchRepository(ctx context.Context, url string, ref string) (err error)
	/*
		Zip a directory for a worspace

		Input arguments:

		  * ctx: A context to pass into the method. Can be used to cancel long running tasks

		  * uuid: Unique identifier for the zip

		  * inputPath: Path to the zip

		  * ignoreRegex: List of regexes to ignore during zip

		Return values:

		  * zipOutput: Path to the zipped output

		  * err: Whether the zip failed

	*/
	ZipWorkspace(ctx context.Context, uuid string, inputPath string, ignoreRegex []string) (zipOutput string, err error)
}
