package workspace

import (
	"context"

	client "github.com/ARM-software/embedded-development-services-client/client"
	"github.com/ARM-software/golang-utils/utils/commonerrors"
	"github.com/Arm-Debug/workspace-service-sdk/workspace/config"
)

// WorkspaceManager is an implementation of IWorkspaceManager
// This implementation follows the delegate pattern and so, does not have any business logic.
type WorkspaceManager struct {
	cfg      *config.WorkspaceManagerConfiguration
	Delegate IWorkspaceManager
}

/*
SetWorkspaceName function: Set the workspace name

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - name: The workspace name

Return values:

  - err: Whether the fetch failed
*/
func (imp *WorkspaceManager) SetWorkspaceName(ctx context.Context, name string) (err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.SetWorkspaceName(ctx, name)
}

/*
GetWorkspaceName function: Get the workspace name

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

Return values:

  - name: The workspace name

  - err: Whether the fetch failed
*/
func (imp *WorkspaceManager) GetWorkspaceName(ctx context.Context) (name *string, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.GetWorkspaceName(ctx)
}

/*
CreateWorkspace function: Create a workspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - name: The workspace name

  - sourceName: The workspace source type (git/zip)

Return values:

  - item: The workspace item

  - err: Whether the creation failed
*/
func (imp *WorkspaceManager) CreateWorkspace(ctx context.Context, name string, sourceName string) (item *client.WorkspaceItem, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.CreateWorkspace(ctx, name, sourceName)
}

/*
RetainWorkspace function: Retain a workspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - name: The workspace name

Return values:

  - item: The workspace item

  - err: Whether the retain failed
*/
func (imp *WorkspaceManager) RetainWorkspace(ctx context.Context, name string) (item *client.WorkspaceItem, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.RetainWorkspace(ctx, name)
}

/*
ListWorkspaces function: List workspaces

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

Return values:

  - collection: The collection of workspaces

  - err: Whether the list failed
*/
func (imp *WorkspaceManager) ListWorkspaces(ctx context.Context) (collection *client.WorkspaceCollection, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.ListWorkspaces(ctx)
}

/*
GetWorkspaceZipSourceEtag function: Get the ETAG for a workspace source of type zip

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - name: The workspace name

Return values:

  - etag: The etag for the zip source

  - err: Whether the etag fetch failed
*/
func (imp *WorkspaceManager) GetWorkspaceZipSourceEtag(ctx context.Context, name string) (etag string, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.GetWorkspaceZipSourceEtag(ctx, name)
}

/*
UploadWorkspaceContent function: Upload content to a workspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - artefact: The artefact to upload

Return values:

  - err: Whether the upload failed
*/
func (imp *WorkspaceManager) UploadWorkspaceContent(ctx context.Context, artefact string) (err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.UploadWorkspaceContent(ctx, artefact)
}

/*
FetchRepository function: Fetch content from a git repository

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - url: Repository URL

  - ref: Repository reference

Return values:

  - err: Whether the fetch failed
*/
func (imp *WorkspaceManager) FetchRepository(ctx context.Context, url string, ref string) (err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.FetchRepository(ctx, url, ref)
}

/*
ZipWorkspace function: Zip a directory for a worspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - uuid: Unique identifier for the zip

  - inputPath: Path to the zip

  - ignoreRegex: List of regexes to ignore during zip

Return values:

  - zipOutput: Path to the zipped output

  - err: Whether the zip failed
*/
func (imp *WorkspaceManager) ZipWorkspace(ctx context.Context, uuid string, inputPath string, ignoreRegex []string) (zipOutput string, err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.ZipWorkspace(ctx, uuid, inputPath, ignoreRegex)
}

// GetConfig returns the configuration for Workspace
func (imp *WorkspaceManager) GetConfig() *config.WorkspaceManagerConfiguration {
	return imp.cfg
}

// NewWorkspaceWithDelegate returns a new IWorkspaceManager that uses the delegate implementation provided by d
func NewWorkspaceWithDelegate(d IWorkspaceManager) IWorkspaceManager {
	if d == nil {
		return nil
	}
	return &WorkspaceManager{
		cfg:      d.GetConfig(),
		Delegate: d,
	}
}
