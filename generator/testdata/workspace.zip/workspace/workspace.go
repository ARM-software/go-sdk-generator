package workspace

import (
	"context"
	"fmt"

	"github.com/Arm-Debug/workspace-service-sdk/workspace/config"

	client "github.com/ARM-software/embedded-development-services-client/client"
	"github.com/ARM-software/golang-utils/utils/commonerrors"
)

// The implementation of IWorkspace
type Workspace struct {
	cfg      *config.WorkspaceConfiguration
	Delegate IWorkspace
}

/*
Set the workspace name

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - name: The workspace name

Return values:

  - err: Whether the fetch failed
*/
func (imp *Workspace) SetWorkspaceName(ctx context.Context, name string) (err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.SetWorkspaceName(ctx, name)
}

/*
Get the workspace name

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

Return values:

  - name: The workspace name

  - err: Whether the fetch failed
*/
func (imp *Workspace) GetWorkspaceName(ctx context.Context) (name *string, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.GetWorkspaceName(ctx)
}

/*
Create a workspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - name: The workspace name

  - sourceName: The workspace source type (git/zip)

Return values:

  - item: The workspace item

  - err: Whether the creation failed
*/
func (imp *Workspace) CreateWorkspace(ctx context.Context, name string, sourceName string) (item *client.WorkspaceItem, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.CreateWorkspace(ctx, name, sourceName)
}

/*
Retain a workspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - name: The workspace name

Return values:

  - item: The workspace item

  - err: Whether the retain failed
*/
func (imp *Workspace) RetainWorkspace(ctx context.Context, name string) (item *client.WorkspaceItem, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.RetainWorkspace(ctx, name)
}

/*
List workspaces

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

Return values:

  - collection: The collection of workspaces

  - err: Whether the list failed
*/
func (imp *Workspace) ListWorkspaces(ctx context.Context) (collection *client.WorkspaceCollection, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.ListWorkspaces(ctx)
}

/*
Get the ETAG for a workspace source of type zip

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - name: The workspace name

Return values:

  - etag: The etag for the zip source

  - err: Whether the etag fetch failed
*/
func (imp *Workspace) GetWorkspaceZipSourceEtag(ctx context.Context, name string) (etag string, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.GetWorkspaceZipSourceEtag(ctx, name)
}

/*
Upload content to a workspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - artefact: The artefact to upload

Return values:

  - err: Whether the upload failed
*/
func (imp *Workspace) UploadWorkspaceContent(ctx context.Context, artefact string) (err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.UploadWorkspaceContent(ctx, artefact)
}

/*
Fetch content from a git repository

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - url: Repository URL

  - ref: Repository reference

Return values:

  - err: Whether the fetch failed
*/
func (imp *Workspace) FetchRepository(ctx context.Context, url string, ref string) (err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.FetchRepository(ctx, url, ref)
}

/*
Zip a directory for a worspace

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long running tasks

  - uuid: Unique identifier for the zip

  - inputPath: Path to the zip

  - ignoreRegex: List of regexes to ignore during zip

Return values:

  - zipOutput: Path to the zipped output

  - err: Whether the zip failed
*/
func (imp *Workspace) ZipWorkspace(ctx context.Context, uuid string, inputPath string, ignoreRegex []string) (zipOutput string, err error) {
	if imp.Delegate == nil {
		err = fmt.Errorf("%w: delegate must be defined", commonerrors.ErrUndefined)
		return
	}

	return imp.Delegate.ZipWorkspace(ctx, uuid, inputPath, ignoreRegex)
}

// GetConfig returns the configuration for Workspace
func (imp *Workspace) GetConfig() *config.WorkspaceConfiguration {
	return imp.cfg
}

// NewWorkspace returns a new Workspace with the configuration provided by cfg
func NewDefaultWorkspace(cfg *config.WorkspaceConfiguration) *Workspace {
	return &Workspace{
		cfg: cfg,
	}
}

// NewWorkspaceWithDelegate returns a new IWorkspace that uses the delegate implementation provided by d
func NewWorkspaceWithDelegate(d IWorkspace) IWorkspace {
	return &Workspace{
		cfg:      d.GetConfig(),
		Delegate: d,
	}
}
