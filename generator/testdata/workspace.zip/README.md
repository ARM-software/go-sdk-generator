# Workspace SDK

[![Go Badge](https://img.shields.io/badge/go-v1.24.4-blue)](https://golang.org/)

Create and manipulate workspaces


## Documentation

To learn more about the SDK and how to use it, please have a look at [our documentation guide](./DOCUMENTATION.md)
