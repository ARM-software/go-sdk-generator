# Workspace SDK

[![Go Badge](https://img.shields.io/badge/go-v1.24-blue)](https://golang.org/)

Create and manipulate workspaces

## Types defined in this package

### WorkspaceConfiguration

WorkspaceConfiguration contains configuration that may be useful.

#### Fields

- **`BearerToken : string`** - An authorisation token for the services (required)
  - This field has to follow the pattern `[a-z]+`


## Interface defined in this package `IWorkspace`

Set the workspace name

```go
SetWorkspaceName(name string) (err error)
```

Input arguments:

  * `name : string`: The workspace name

Return values:

  * `err : error`: Whether the fetch failed


Get the workspace name

```go
GetWorkspaceName() (name *string, err error)
```

Input arguments:

Return values:

  * `name : string`: The workspace name

  * `err : error`: Whether the fetch failed


Create a workspace

```go
CreateWorkspace(name string, sourceName string) (item *client.WorkspaceItem, err error)
```

Input arguments:

  * `name : string`: The workspace name

  * `sourceName : string`: The workspace source type (git/zip)

Return values:

  * `item : client.WorkspaceItem`: The workspace item

  * `err : error`: Whether the creation failed


Retain a workspace

```go
RetainWorkspace(name string) (item *client.WorkspaceItem, err error)
```

Input arguments:

  * `name : string`: The workspace name

Return values:

  * `item : client.WorkspaceItem`: The workspace item

  * `err : error`: Whether the retain failed


List workspaces

```go
ListWorkspaces() (collection *client.WorkspaceCollection, err error)
```

Input arguments:

Return values:

  * `collection : client.WorkspaceCollection`: The collection of workspaces

  * `err : error`: Whether the list failed


Get the ETAG for a workspace source of type zip

```go
GetWorkspaceZipSourceEtag(name string) (etag string, err error)
```

Input arguments:

  * `name : string`: The workspace name

Return values:

  * `etag : string`: The etag for the zip source

  * `err : error`: Whether the etag fetch failed


Upload content to a workspace

```go
UploadWorkspaceContent(artefact string) (err error)
```

Input arguments:

  * `artefact : string`: The artefact to upload

Return values:

  * `err : error`: Whether the upload failed


Fetch content from a git repository

```go
FetchRepository(url string, ref string) (err error)
```

Input arguments:

  * `url : string`: Repository URL

  * `ref : string`: Repository reference

Return values:

  * `err : error`: Whether the fetch failed


Zip a directory for a worspace

```go
ZipWorkspace(uuid string, inputPath string, ignoreRegex []string) (zipOutput string, err error)
```

Input arguments:

  * `uuid : string`: Unique identifier for the zip

  * `inputPath : string`: Path to the zip

  * `ignoreRegex : []string`: List of regexes to ignore during zip

Return values:

  * `zipOutput : string`: Path to the zipped output

  * `err : error`: Whether the zip failed

