package agent

import (
	"context"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	"github.com/Arm-Debug/fpga-service-agent/agent/config"
	credentials "github.com/Arm-Debug/fpga-service-common/common/agent/credentials"
)

// FPGAServiceAgentManager is an implementation of IFPGAServiceAgentManager
// This implementation follows the delegate pattern and so, does not have any business logic.
type FPGAServiceAgentManager struct {
	cfg      *config.FPGAServiceAgentManagerConfiguration
	Delegate IFPGAServiceAgentManager
}

// Close closes any opened resources (See io.Close).
func (imp *FPGAServiceAgentManager) Close() (err error) {
	if imp.Delegate == nil {
		return
	}
	err = imp.Close()
	return
}

/*
Initialise function: Initialise the agent with information about the FPGA under supervision

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

  - manifestFile: Path to the manifest file describing the FPGA under supervision

  - agentCredentials: credentials necessary for setting up the agent with AFaaS

Return values:

  - err: Whether a halting error was hit causing the agent to exit
*/
func (imp *FPGAServiceAgentManager) Initialise(ctx context.Context, manifestFile string, agentCredentials credentials.IFPGAAgentCredentials) (err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.Initialise(ctx, manifestFile, agentCredentials)
}

/*
Run function: Run the agent

Input arguments:

  - ctx: A context to pass into the method. Can be used to cancel long-running tasks

Return values:

  - err: Whether a halting error was hit causing the agent to exit
*/
func (imp *FPGAServiceAgentManager) Run(ctx context.Context) (err error) {
	if imp.Delegate == nil {
		err = commonerrors.UndefinedVariable("delegate")
		return
	}

	return imp.Delegate.Run(ctx)
}

// GetConfig returns the configuration for FPGAServiceAgent
func (imp *FPGAServiceAgentManager) GetConfig() *config.FPGAServiceAgentManagerConfiguration {
	return imp.cfg
}

// NewFPGAServiceAgentWithDelegate returns a new IFPGAServiceAgentManager that uses the delegate implementation provided by d
func NewFPGAServiceAgentWithDelegate(d IFPGAServiceAgentManager) IFPGAServiceAgentManager {
	if d == nil {
		return nil
	}
	return &FPGAServiceAgentManager{
		cfg:      d.GetConfig(),
		Delegate: d,
	}
}
