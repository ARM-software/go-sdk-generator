package types

import (
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"

	encryption "github.com/ARM-software/golang-utils/utils/encryption/aesrsa"
)

// AuthenticationPayload represents authentication payload for authenticating a payload with the boundary controller
type AuthenticationPayload struct {
	// MachineHostName is the machine host name of currently running agent
	MachineHostName string `json:"machine_host" mapstructure:"machine_host_name"`
	// EncryptedPayload is a payload containing the worker authentication key encrypted with hybrid RSA AES encryption
	EncryptedPayload *encryption.HybridAESRSAEncryptedPayload `json:"encrypted_payload,omitempty" mapstructure:"encrypted_payload"`
}

func (cfg *AuthenticationPayload) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg)
}

func DefaultAuthenticationPayload() *AuthenticationPayload {
	return &AuthenticationPayload{}
}
