package config

import (
	"os"
	"time"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
)

// FPGAServiceAgentManagerConfiguration provides some configuration data object for FPGAServiceAgent
type FPGAServiceAgentManagerConfiguration struct {
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`
	// the host name of the machine on which the agent runs
	MachineHostName string `mapstructure:"host_name"`
	// Exclude the provisioning steps (provisioning or decommissioning)
	NoProvisioning bool `mapstructure:"no_provisioning"`
	// whether to not start the Agent HTTP server
	NoHTTPServer bool `mapstructure:"no_api_server"`
	// The host to run the agent HTTP server on
	APIHost string `mapstructure:"api_host"`
	// The port to run the agent HTTP server on
	APIPort uint32 `mapstructure:"api_port"`
	// A path to a store that will be used as a persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataStore string `mapstructure:"data_store"`
	// Whether to run the agent as mock
	MockAgent bool `mapstructure:"mock_agent"`
	// The default timeout for jobs
	DefaultJobTimeout time.Duration `mapstructure:"default_job_timeout"`
	// Override the wrapper script used for running and monitoring jobs on FPGA hosts
	RunJobWrapper string `mapstructure:"run_job_wrapper"`
}

func (cfg *FPGAServiceAgentManagerConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.Sandpit, validation.Required),
		validation.Field(&cfg.MachineHostName, validation.Required),
		validation.Field(&cfg.NoProvisioning),
		validation.Field(&cfg.NoHTTPServer),
		validation.Field(&cfg.APIHost, is.URL),
		validation.Field(&cfg.APIPort, is.Port),
		validation.Field(&cfg.DataStore, validation.Required),
		validation.Field(&cfg.MockAgent),
		validation.Field(&cfg.DefaultJobTimeout, validation.Required),
	)
}

func DefaultFPGAServiceAgentManagerConfiguration() *FPGAServiceAgentManagerConfiguration {
	return &FPGAServiceAgentManagerConfiguration{
		MachineHostName: func() string {
			hostname, _ := os.Hostname()
			return hostname
		}(),
		APIHost: "localhost",
		APIPort: 8080,
		DefaultJobTimeout: func() time.Duration {
			duration, _ := time.ParseDuration("5m")
			return duration
		}(),
	}
}
