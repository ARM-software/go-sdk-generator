module github.com/Arm-Debug/fpga-service-agent/agent

go 1.24.6

toolchain go1.24.6

tool (
	github.com/dmarkham/enumer
	go.uber.org/mock/mockgen
)