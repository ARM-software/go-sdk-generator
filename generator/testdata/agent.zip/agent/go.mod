module github.com/Arm-Debug/fpga-service-agent/agent

go 1.24.4

toolchain go1.24.4

tool (
	github.com/dmarkham/enumer
	go.uber.org/mock/mockgen
)