#!/bin/bash

cd agent || exit 1
go mod tidy
go generate ./...
cd .. || exit 1

cd cli || exit 1
go build -o fpga-service-agent .
mkdir ../.manpages
./fpga-service-agent man >../.manpages/fpga-service-agent.1
