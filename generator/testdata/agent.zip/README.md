# FPGAServiceAgent SDK

[![Go Badge](https://img.shields.io/badge/go-v1.24.6-blue)](https://golang.org/)

The FPGA Service Agent manages the FPGA host tools and the connection to the FPGA serial connection

> :gear: This project also comes with [CLI tools and commands](./DOCUMENTATION.md#cli_tools) for ease of use

You can access the man page for the CLI via:
```sh
man fpga-service-agent
```

## Documentation

To learn more about the SDK and how to use it, please have a look at [our documentation guide](./DOCUMENTATION.md)
