// Package cmd defines all the CLI commands for FPGAServiceAgent
package cmd

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/field"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/spf13/cobra"

	"github.com/Arm-Debug/fpga-service-agent/cli/cmd/agent"
	"github.com/Arm-Debug/fpga-service-agent/cli/cmd/config"
)

const (
	decommissionAPITokenArg        = "api-token" //nolint:gosec // not a secret
	decommissionAPIurlArg          = "api-url"
	initAFAASHostArg               = "afaas-service-host"
	initAFAASStoreHostArg          = "afaas-store-host"
	initAFAASStorePayloadOwnersArg = "afaas-store-payload-owners"
	initAFAASStorePublicKeyArg     = "afaas-store-public-key" //nolint:gosec // not a secret
	initAFAASStoreTokenArg         = "afaas-store-token"      //nolint:gosec // not a secret
	initAFAASTokenArg              = "afaas-service-token"    //nolint:gosec // not a secret
	initAgentAPITokenArg           = "agent-api-token"        //nolint:gosec // not a secret
	initDataFileArg                = "local-data-store"
	initMachineHostNameArg         = "host-name"
	initManifestFileArg            = "manifest-file"
	initNoProvisionArg             = "no-provision"
	initSandpitArg                 = "sandpit"
	serveAPIHostArg                = "api-host"
	serveAPIPortArg                = "api-port"
	serveDataFileArg               = "local-data-store"
	serveDefaultJobTimeoutArg      = "default-job-timeout"
	serveMachineHostNameArg        = "host-name"
	serveMockServerArg             = "mock-server"
	serveNoAPIArg                  = "no-api"
	serveNoProvisionArg            = "no-provision"
	serveRunJobWrapperArg          = "run-job-wrapper"
	serveSandpitArg                = "sandpit"
	validateContentArg             = "content"
	validateManifestFileArg        = "manifest-file"
)

func addInterruptHandlerToContext(ctx context.Context) (cancellableCtx context.Context, cancel context.CancelFunc) {
	cancellableCtx, cancel = context.WithCancel(ctx)
	end := make(chan error, 1)
	go func() {
		// Waits for a user interrupt or SIGTERM or expired/cancelled context
		shutdown := make(chan os.Signal, 1)
		signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
		for wait := true; wait; {
			select {
			case <-shutdown:
				wait = false
			case <-ctx.Done():
				wait = false
			}
		}

		cancel()
		close(end)
	}()
	return
}

var serveCmd = &cobra.Command{
	Use:   "serve",
	Short: "Start the FPGA service agent so it serves AFaaS job requests",
	Long:  "Start the FPGA service agent so it serves AFaaS job requests",
	RunE: func(cmd *cobra.Command, args []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Serve")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var serveCfg config.ServeConfiguration

		err = configUtils.LoadFromViper(viperSession, app, &serveCfg, config.DefaultServeConfiguration())
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			serveCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}

		err = agent.WrapServe(cancellableCtx, logger, &serveCfg, agent.ServeImplFunc)
		if err != nil {
			cancel()
			return
		}

		return
	},
}

var validateCmd = &cobra.Command{
	Use:   "validate",
	Short: "Validate an FPGA manifest file",
	Long:  "Validate an FPGA manifest file",
	RunE: func(cmd *cobra.Command, args []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Validate")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var validateCfg config.ValidateConfiguration

		err = configUtils.LoadFromViper(viperSession, app, &validateCfg, config.DefaultValidateConfiguration())
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			validateCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}

		err = agent.WrapValidate(cancellableCtx, logger, &validateCfg, agent.ValidateImplFunc)
		if err != nil {
			cancel()
			return
		}

		return
	},
}

var initCmd = &cobra.Command{
	Use:   "init",
	Short: "Initialise the internal datastore so it is available to the agent",
	Long:  "Initialise the internal datastore so it is available to the agent",
	RunE: func(cmd *cobra.Command, args []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Init")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var initCfg config.InitConfiguration

		err = configUtils.LoadFromViper(viperSession, app, &initCfg, config.DefaultInitConfiguration())
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			initCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}

		err = agent.WrapInit(cancellableCtx, logger, &initCfg, agent.InitImplFunc)
		if err != nil {
			cancel()
			return
		}

		return
	},
}

var decommissionCmd = &cobra.Command{
	Use:   "decommission",
	Short: "Decommission a running FPGA agent",
	Long:  "Decommission a running FPGA agent",
	RunE: func(cmd *cobra.Command, args []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Decommission")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var decommissionCfg config.DecommissionConfiguration

		err = configUtils.LoadFromViper(viperSession, app, &decommissionCfg, config.DefaultDecommissionConfiguration())
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel()

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			decommissionCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}

		err = agent.WrapDecommission(cancellableCtx, logger, &decommissionCfg, agent.DecommissionImplFunc)
		if err != nil {
			cancel()
			return
		}

		return
	},
}

func init() {
	serveCmd.Flags().String(serveSandpitArg, "", "The path to the directory where the Agent can store data/files/artefacts it needs to run")
	serveCmd.Flags().String(serveDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	serveCmd.Flags().Bool(serveNoProvisionArg, false, "Do not make provisioning requests to the service (provisioning or decommissioning)")
	serveCmd.Flags().String(serveMachineHostNameArg, "", "the host name of the machine on which the agent runs")
	serveCmd.Flags().Bool(serveNoAPIArg, false, "Do not start the Agent's API server")
	serveCmd.Flags().String(serveAPIHostArg, "", "The host to run the agent API on")
	serveCmd.Flags().Int(serveAPIPortArg, 0, "The port to run the agent API on")
	serveCmd.Flags().Duration(serveDefaultJobTimeoutArg, 0, "The default timeout for jobs")
	serveCmd.Flags().Bool(serveMockServerArg, false, "Whether to run the server as a mock server (no FPGA access)")
	serveCmd.Flags().String(serveRunJobWrapperArg, "", "Override the the wrapper script used for running and monitoring jobs on FPGA hosts")
	validateCmd.Flags().String(validateManifestFileArg, "", "The path to the FPGA manifest file")
	validateCmd.Flags().Bool(validateContentArg, false, "Whether the validation should also include the validation of the content itself (not just syntax)")
	initCmd.Flags().String(initAgentAPITokenArg, "", "An API token to enforce authorisation when communicating with the agent via the API server")
	initCmd.Flags().String(initManifestFileArg, "", "The path to the FPGA manifest file")
	initCmd.Flags().String(initSandpitArg, "", "The path to the directory where the Agent can store data/files/artefacts it needs to run")
	initCmd.Flags().String(initAFAASHostArg, "", "The host of the FPGA service itself")
	initCmd.Flags().String(initAFAASTokenArg, "", "An API token for the agent to authenticate with the FPGA service itself")
	initCmd.Flags().String(initAFAASStoreHostArg, "", "The host to the payload store")
	initCmd.Flags().String(initAFAASStoreTokenArg, "", "An API token for the agent to authenticate with the payload store")
	initCmd.Flags().String(initAFAASStorePublicKeyArg, "", "The public key used to verify the authenticity of payloads")
	initCmd.Flags().String(initAFAASStorePayloadOwnersArg, "", "Comma separated list of payload owners accepted by this agent")
	initCmd.Flags().String(initDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	initCmd.Flags().Bool(initNoProvisionArg, false, "Do not make provisioning requests to the service (provisioning or decommissioning)")
	initCmd.Flags().String(initMachineHostNameArg, "", "the host name of the machine on which the agent runs")
	decommissionCmd.Flags().String(decommissionAPIurlArg, "", "The URL the FPGA agent API is running on")
	decommissionCmd.Flags().String(decommissionAPITokenArg, "", "The token used to authenticate with the FPGA agent API")

	_ = configUtils.BindFlagToEnv(viperSession, app, "afaas_service_host", initCmd.Flags().Lookup(initAFAASHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "afaas_service_token", initCmd.Flags().Lookup(initAFAASTokenArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "afaas_store_host", initCmd.Flags().Lookup(initAFAASStoreHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "afaas_store_payload_owners", initCmd.Flags().Lookup(initAFAASStorePayloadOwnersArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "afaas_store_public_key", initCmd.Flags().Lookup(initAFAASStorePublicKeyArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "afaas_store_token", initCmd.Flags().Lookup(initAFAASStoreTokenArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "agent_api_token", initCmd.Flags().Lookup(initAgentAPITokenArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "api_host", serveCmd.Flags().Lookup(serveAPIHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "api_port", serveCmd.Flags().Lookup(serveAPIPortArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "api_token", decommissionCmd.Flags().Lookup(decommissionAPITokenArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "api_url", decommissionCmd.Flags().Lookup(decommissionAPIurlArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "content", validateCmd.Flags().Lookup(validateContentArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "default_job_timeout", serveCmd.Flags().Lookup(serveDefaultJobTimeoutArg))
	_ = configUtils.BindFlagsToEnv(viperSession, app, "host_name", serveCmd.Flags().Lookup(serveMachineHostNameArg), initCmd.Flags().Lookup(initMachineHostNameArg))
	_ = configUtils.BindFlagsToEnv(viperSession, app, "local_data_store", serveCmd.Flags().Lookup(serveDataFileArg), initCmd.Flags().Lookup(initDataFileArg))
	_ = configUtils.BindFlagsToEnv(viperSession, app, "manifest_file", validateCmd.Flags().Lookup(validateManifestFileArg), initCmd.Flags().Lookup(initManifestFileArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "mock_server", serveCmd.Flags().Lookup(serveMockServerArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "no_api", serveCmd.Flags().Lookup(serveNoAPIArg))
	_ = configUtils.BindFlagsToEnv(viperSession, app, "no_provision", serveCmd.Flags().Lookup(serveNoProvisionArg), initCmd.Flags().Lookup(initNoProvisionArg))
	_ = configUtils.BindFlagToEnv(viperSession, app, "run_job_wrapper", serveCmd.Flags().Lookup(serveRunJobWrapperArg))
	_ = configUtils.BindFlagsToEnv(viperSession, app, "sandpit", serveCmd.Flags().Lookup(serveSandpitArg), initCmd.Flags().Lookup(initSandpitArg))

	rootCmd.AddCommand(serveCmd)
	rootCmd.AddCommand(validateCmd)
	rootCmd.AddCommand(initCmd)
	rootCmd.AddCommand(decommissionCmd)
}
