// Package cmd defines all the CLI commands for FPGAServiceAgent
package cmd

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/field"
	"github.com/ARM-software/golang-utils/utils/keyring"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/spf13/cobra"

	"github.com/Arm-Debug/fpga-service-agent/cli/cmd/agent"
	"github.com/Arm-Debug/fpga-service-agent/cli/cmd/config"
)

const (
	aFaaSCredentialsDataFileArg       = "local-data-store"
	aFaaSCredentialsSandpitArg        = "sandpit"
	credentialsAFAASHostArg           = "afaas-service-host"
	credentialsAFAASStoreHostArg      = "afaas-store-host"
	credentialsAFAASStorePublicKeyArg = "afaas-store-public-key" //nolint:gosec // not a secret
	credentialsAFAASStoreTokenArg     = "afaas-store-token"      //nolint:gosec // not a secret
	credentialsAFAASTokenArg          = "afaas-service-token"    //nolint:gosec // not a secret
	credentialsDataFileArg            = "local-data-store"
	credentialsMachineHostNameArg     = "host-name"
	credentialsSandpitArg             = "sandpit"
	decommissionDataFileArg           = "local-data-store"
	decommissionNoKeyringArg          = "no-keyring" //nolint:gosec // not a secret
	initAFAASHostArg                  = "afaas-service-host"
	initAFAASStoreHostArg             = "afaas-store-host"
	initAFAASStorePayloadOwnersArg    = "afaas-store-payload-owners"
	initAFAASStorePublicKeyArg        = "afaas-store-public-key" //nolint:gosec // not a secret
	initAFAASStoreTokenArg            = "afaas-store-token"      //nolint:gosec // not a secret
	initAFAASTokenArg                 = "afaas-service-token"    //nolint:gosec // not a secret
	initAgentAPITokenArg              = "agent-api-token"        //nolint:gosec // not a secret
	initDataFileArg                   = "local-data-store"
	initMachineHostNameArg            = "host-name"
	initManifestFileArg               = "manifest-file"
	initNoKeyringArg                  = "no-keyring" //nolint:gosec // not a secret
	initNoProvisionArg                = "no-provision"
	initSandpitArg                    = "sandpit"
	serveAPIHostArg                   = "api-host"
	serveAPIPortArg                   = "api-port"
	serveDataFileArg                  = "local-data-store"
	serveDefaultJobTimeoutArg         = "default-job-timeout"
	serveMachineHostNameArg           = "host-name"
	serveMockServerArg                = "mock-server"
	serveNoAPIArg                     = "no-api"
	serveNoKeyringArg                 = "no-keyring" //nolint:gosec // not a secret
	serveNoProvisionArg               = "no-provision"
	serveRunJobWrapperArg             = "run-job-wrapper"
	serveSandpitArg                   = "sandpit"
	validateContentArg                = "content"
	validateManifestFileArg           = "manifest-file"
)

func addInterruptHandlerToContext(ctx context.Context) (cancellableCtx context.Context, cancel context.CancelCauseFunc) {
	var cause error
	cancellableCtx, cancel = context.WithCancelCause(ctx)
	end := make(chan error, 1)
	go func() {
		// Waits for a user interrupt or SIGTERM or expired/cancelled context
		shutdown := make(chan os.Signal, 1)
		signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM, os.Interrupt)
		for wait := true; wait; {
			select {
			case s := <-shutdown:
				cause = commonerrors.Newf(commonerrors.ErrInterrupted, "received signal '%v'", s)
				wait = false
			case <-ctx.Done():
				wait = false
			}
		}

		cancel(cause)
		close(end)
	}()
	return
}

var serveCmd = &cobra.Command{
	Use:   "serve",
	Short: "Start the FPGA service agent so it serves AFaaS job requests",
	Long:  "Start the FPGA service agent so it serves AFaaS job requests",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Serve")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var serveCfg config.ServeConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultServeConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		cfgLoadOptions = append(cfgLoadOptions, configUtils.WithKeyring(!cmd.Flags().Changed(serveNoKeyringArg)))
		err = configUtils.LoadUsing(&serveCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			serveCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}
		err = agent.WrapServe(cancellableCtx, logger, &serveCfg, agent.ServeImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		return
	},
}

var validateCmd = &cobra.Command{
	Use:   "validate",
	Short: "Validate an FPGA manifest file",
	Long:  "Validate an FPGA manifest file",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Validate")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var validateCfg config.ValidateConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultValidateConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		err = configUtils.LoadUsing(&validateCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			validateCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}
		err = agent.WrapValidate(cancellableCtx, logger, &validateCfg, agent.ValidateImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		return
	},
}

var initCmd = &cobra.Command{
	Use:   "init",
	Short: "Initialise the internal datastore so it is available to the agent",
	Long:  "Initialise the internal datastore so it is available to the agent",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Init")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var initCfg config.InitConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultInitConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		cfgLoadOptions = append(cfgLoadOptions, configUtils.WithKeyring(!cmd.Flags().Changed(initNoKeyringArg)))
		err = configUtils.LoadUsing(&initCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			initCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}
		err = agent.WrapInit(cancellableCtx, logger, &initCfg, agent.InitImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		return
	},
}

var credentialsCmd = &cobra.Command{
	Use:   "credentials",
	Short: "Store AFaaS agent's credentials securely in the platform",
	Long:  "Store AFaaS agent's credentials securely in the platform",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Credentials")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var credentialsCfg config.CredentialsConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultCredentialsConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		err = configUtils.LoadUsing(&credentialsCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		credentialsCfg.ToolVersion = nil
		err = agent.WrapCredentials(cancellableCtx, logger, &credentialsCfg, agent.CredentialsImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		err = keyring.Store[config.CredentialsConfiguration](cancellableCtx, config.App, &credentialsCfg)
		if err != nil {
			cancel(nil)
			if commonerrors.Any(err, commonerrors.ErrUnsupported) {
				err = commonerrors.WrapError(commonerrors.ErrUnsupported, err, "configuration cannot be stored in system's keyring")
			} else {
				err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed storing configuration into system's keyring")
			}
			return
		}
		logger.Log("successfully stored credentials in system's keyring")
		return
	},
}

var afaascredentialsCmd = &cobra.Command{
	Use:   "afaascredentials",
	Short: "Store AFaaS service's credentials securely in the platform",
	Long:  "Store AFaaS service's credentials securely in the platform",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("AFaaSCredentials")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var afaascredentialsCfg config.AFaaSCredentialsConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultAFaaSCredentialsConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		err = configUtils.LoadUsing(&afaascredentialsCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		afaascredentialsCfg.ToolVersion = nil
		err = agent.WrapAFaaSCredentials(cancellableCtx, logger, &afaascredentialsCfg, agent.AFaaSCredentialsImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		err = keyring.Store[config.AFaaSCredentialsConfiguration](cancellableCtx, config.App, &afaascredentialsCfg)
		if err != nil {
			cancel(nil)
			if commonerrors.Any(err, commonerrors.ErrUnsupported) {
				err = commonerrors.WrapError(commonerrors.ErrUnsupported, err, "configuration cannot be stored in system's keyring")
			} else {
				err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed storing configuration into system's keyring")
			}
			return
		}
		logger.Log("successfully stored credentials in system's keyring")
		return
	},
}

var decommissionCmd = &cobra.Command{
	Use:   "decommission",
	Short: "Decommission a running FPGA agent",
	Long:  "Decommission a running FPGA agent",
	RunE: func(cmd *cobra.Command, _ []string) (err error) {
		ctx := context.Background()
		logger, err := logs.NewStdLogger("Decommission")
		if err != nil {
			err = commonerrors.WrapError(commonerrors.ErrUnexpected, err, "failed initialising the logger")
			return
		}

		var decommissionCfg config.DecommissionConfiguration
		cfgLoadOptions := []configUtils.LoadingOption{
			configUtils.WithEnvVarPrefix(config.App),
			configUtils.WithDefaultConfiguration(config.DefaultDecommissionConfiguration()),
			configUtils.WithViperSession(viperSession),
		}
		cfgLoadOptions = append(cfgLoadOptions, configUtils.WithKeyring(!cmd.Flags().Changed(decommissionNoKeyringArg)))
		err = configUtils.LoadUsing(&decommissionCfg, cfgLoadOptions...)
		if err != nil {
			return
		}

		cancellableCtx, cancel := addInterruptHandlerToContext(ctx)
		defer cancel(nil)

		cliVersion, err := semver.DetermineEmbeddedVersion(cancellableCtx, &embeddedFS, nil)
		if err == nil {
			decommissionCfg.ToolVersion = field.ToOptionalString(cliVersion)
		}
		err = agent.WrapDecommission(cancellableCtx, logger, &decommissionCfg, agent.DecommissionImplFunc)
		if err != nil {
			cancel(nil)
			return
		}

		return
	},
}

func init() {
	serveCmd.Flags().String(serveAPIHostArg, "", "The host to run the agent API on")
	serveCmd.Flags().Int(serveAPIPortArg, 0, "The port to run the agent API on")
	serveCmd.Flags().String(serveDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	serveCmd.Flags().Duration(serveDefaultJobTimeoutArg, 0, "The default timeout for jobs")
	serveCmd.Flags().String(serveMachineHostNameArg, "", "the host name of the machine on which the agent runs")
	serveCmd.Flags().Bool(serveMockServerArg, false, "Whether to run the server as a mock server (no FPGA access)")
	serveCmd.Flags().Bool(serveNoAPIArg, false, "Do not start the Agent's API server")
	serveCmd.Flags().Bool(serveNoKeyringArg, false, "Disable loading configuration from the system keyring")
	serveCmd.Flags().Bool(serveNoProvisionArg, false, "Do not make provisioning requests to the service (provisioning or decommissioning)")
	serveCmd.Flags().String(serveRunJobWrapperArg, "", "Override the the wrapper script used for running and monitoring jobs on FPGA hosts")
	serveCmd.Flags().String(serveSandpitArg, "", "The path to the directory where the Agent can store data/files/artefacts it needs to run")
	validateCmd.Flags().String(validateManifestFileArg, "", "The path to the FPGA manifest file")
	validateCmd.Flags().Bool(validateContentArg, false, "Whether the validation should also include the validation of the content itself (not just syntax)")
	initCmd.Flags().String(initAFAASHostArg, "", "The host of the FPGA service itself")
	initCmd.Flags().String(initAFAASStoreHostArg, "", "The host to the payload store")
	initCmd.Flags().String(initAFAASStorePayloadOwnersArg, "", "Comma separated list of payload owners accepted by this agent")
	initCmd.Flags().String(initAFAASStorePublicKeyArg, "", "The public key used to verify the authenticity of payloads")
	initCmd.Flags().String(initAFAASStoreTokenArg, "", "An API token for the agent to authenticate with the payload store")
	initCmd.Flags().String(initAFAASTokenArg, "", "An API token for the agent to authenticate with the FPGA service itself")
	initCmd.Flags().String(initAgentAPITokenArg, "", "An API token to enforce authorisation when communicating with the agent via the API server")
	initCmd.Flags().String(initDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	initCmd.Flags().String(initMachineHostNameArg, "", "the host name of the machine on which the agent runs")
	initCmd.Flags().String(initManifestFileArg, "", "The path to the FPGA manifest file")
	initCmd.Flags().Bool(initNoKeyringArg, false, "Disable loading configuration from the system keyring")
	initCmd.Flags().Bool(initNoProvisionArg, false, "Do not make provisioning requests to the service (provisioning or decommissioning)")
	initCmd.Flags().String(initSandpitArg, "", "The path to the directory where the Agent can store data/files/artefacts it needs to run")
	credentialsCmd.Flags().String(credentialsSandpitArg, "", "The path to the directory where the Agent can store data/files/artefacts it needs to run")
	credentialsCmd.Flags().String(credentialsAFAASHostArg, "", "The host of the FPGA service itself")
	credentialsCmd.Flags().String(credentialsAFAASTokenArg, "", "An API token for the agent to authenticate with the FPGA service itself")
	credentialsCmd.Flags().String(credentialsAFAASStoreHostArg, "", "The host to the payload store")
	credentialsCmd.Flags().String(credentialsAFAASStoreTokenArg, "", "An API token for the agent to authenticate with the payload store")
	credentialsCmd.Flags().String(credentialsDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	credentialsCmd.Flags().String(credentialsAFAASStorePublicKeyArg, "", "The public key used to verify the authenticity of payloads")
	credentialsCmd.Flags().String(credentialsMachineHostNameArg, "", "the host name of the machine on which the agent runs")
	afaascredentialsCmd.Flags().String(aFaaSCredentialsDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	afaascredentialsCmd.Flags().String(aFaaSCredentialsSandpitArg, "", "The path to the directory where the Agent can store data/files/artefacts it needs to run")
	decommissionCmd.Flags().String(decommissionDataFileArg, "", "A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.")
	decommissionCmd.Flags().Bool(decommissionNoKeyringArg, false, "Disable loading configuration from the system keyring")

	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "afaas_service_host", initCmd.Flags().Lookup(initAFAASHostArg), credentialsCmd.Flags().Lookup(credentialsAFAASHostArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "afaas_service_token", initCmd.Flags().Lookup(initAFAASTokenArg), credentialsCmd.Flags().Lookup(credentialsAFAASTokenArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "afaas_store_host", initCmd.Flags().Lookup(initAFAASStoreHostArg), credentialsCmd.Flags().Lookup(credentialsAFAASStoreHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "afaas_store_payload_owners", initCmd.Flags().Lookup(initAFAASStorePayloadOwnersArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "afaas_store_public_key", initCmd.Flags().Lookup(initAFAASStorePublicKeyArg), credentialsCmd.Flags().Lookup(credentialsAFAASStorePublicKeyArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "afaas_store_token", initCmd.Flags().Lookup(initAFAASStoreTokenArg), credentialsCmd.Flags().Lookup(credentialsAFAASStoreTokenArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "agent_api_token", initCmd.Flags().Lookup(initAgentAPITokenArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "api_host", serveCmd.Flags().Lookup(serveAPIHostArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "api_port", serveCmd.Flags().Lookup(serveAPIPortArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "content", validateCmd.Flags().Lookup(validateContentArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "default_job_timeout", serveCmd.Flags().Lookup(serveDefaultJobTimeoutArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "host_name", serveCmd.Flags().Lookup(serveMachineHostNameArg), initCmd.Flags().Lookup(initMachineHostNameArg), credentialsCmd.Flags().Lookup(credentialsMachineHostNameArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "local_data_store", serveCmd.Flags().Lookup(serveDataFileArg), initCmd.Flags().Lookup(initDataFileArg), credentialsCmd.Flags().Lookup(credentialsDataFileArg), afaascredentialsCmd.Flags().Lookup(aFaaSCredentialsDataFileArg), decommissionCmd.Flags().Lookup(decommissionDataFileArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "manifest_file", validateCmd.Flags().Lookup(validateManifestFileArg), initCmd.Flags().Lookup(initManifestFileArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "mock_server", serveCmd.Flags().Lookup(serveMockServerArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "no_api", serveCmd.Flags().Lookup(serveNoAPIArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "no_keyring", serveCmd.Flags().Lookup(serveNoKeyringArg), initCmd.Flags().Lookup(initNoKeyringArg), decommissionCmd.Flags().Lookup(decommissionNoKeyringArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "no_provision", serveCmd.Flags().Lookup(serveNoProvisionArg), initCmd.Flags().Lookup(initNoProvisionArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "run_job_wrapper", serveCmd.Flags().Lookup(serveRunJobWrapperArg))
	_ = configUtils.BindFlagsToEnv(viperSession, config.App, "sandpit", serveCmd.Flags().Lookup(serveSandpitArg), initCmd.Flags().Lookup(initSandpitArg), credentialsCmd.Flags().Lookup(credentialsSandpitArg), afaascredentialsCmd.Flags().Lookup(aFaaSCredentialsSandpitArg))

	rootCmd.AddCommand(serveCmd)
	rootCmd.AddCommand(validateCmd)
	rootCmd.AddCommand(initCmd)
	rootCmd.AddCommand(credentialsCmd)
	rootCmd.AddCommand(afaascredentialsCmd)
	rootCmd.AddCommand(decommissionCmd)
}
