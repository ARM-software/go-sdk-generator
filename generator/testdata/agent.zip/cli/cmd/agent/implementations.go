// Package agent contains the implementation for all the CLI commands.
// Importing the package also performs the automatic binding between the definition and the implementation.
package agent

import (
	"context"

	"github.com/ARM-software/golang-utils/utils/commonerrors"
	"github.com/ARM-software/golang-utils/utils/logs"
	"github.com/Arm-Debug/fpga-service-agent/cli/cmd/config"
)

/*
Serve function: Start the FPGA service agent so it serves AFaaS job requests
*/
func Serve(ctx context.Context, logger logs.Loggers, cfg *config.ServeConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. agent.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Serve()` implementation")
}

/*
Validate function: Validate an FPGA manifest file
*/
func Validate(ctx context.Context, logger logs.Loggers, cfg *config.ValidateConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. agent.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Validate()` implementation")
}

/*
Init function: Initialise the internal datastore so it is available to the agent
*/
func Init(ctx context.Context, logger logs.Loggers, cfg *config.InitConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. agent.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Init()` implementation")
}

/*
Credentials function: Store AFaaS agent's credentials securely in the platform
*/
func Credentials(ctx context.Context, logger logs.Loggers, cfg *config.CredentialsConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. agent.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Credentials()` implementation")
}

/*
AFaaSCredentials function: Store AFaaS service's credentials securely in the platform
*/
func AFaaSCredentials(ctx context.Context, logger logs.Loggers, cfg *config.AFaaSCredentialsConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. agent.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `AFaaSCredentials()` implementation")
}

/*
Decommission function: Decommission a running FPGA agent
*/
func Decommission(ctx context.Context, logger logs.Loggers, cfg *config.DecommissionConfiguration) (err error) {

	// TODO implement me
	// Note: this function code was generated to help setting up the project. It can be moved to separate files
	//       if this helps readiness, as long as it remains in the same module i.e. agent.
	return commonerrors.New(commonerrors.ErrNotImplemented, "missing `Decommission()` implementation")
}

func init() {
	// Note: The following makes the link between the CLI command definitions and their actual implementations.
	// The binding is performed at runtime when package agent is imported.
	// TODO uncomment when implemented
	//  ServeImplFunc = Serve
	//  ValidateImplFunc = Validate
	//  InitImplFunc = Init
	//  CredentialsImplFunc = Credentials
	//  AFaaSCredentialsImplFunc = AFaaSCredentials
	//  DecommissionImplFunc = Decommission
}
