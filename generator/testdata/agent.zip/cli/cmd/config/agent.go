package config

import (
	"crypto/rand"
	"os"
	"path/filepath"
	"regexp"
	"time"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
)

const (
	App = "FPGA_SERVICE_AGENT"
)

// ServeConfiguration defines the configuration for Serve command
type ServeConfiguration struct {
	// The host to run the agent API on
	APIHost string `mapstructure:"api_host"`
	// An API key enabling the use of the online services
	APIKey string `mapstructure:"api_key"`
	// The port to run the agent API on
	APIPort int `mapstructure:"api_port"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// The default timeout for jobs
	DefaultJobTimeout time.Duration `mapstructure:"default_job_timeout"`
	// The host to use for accessing the online services
	Host string `mapstructure:"host"`
	// the host name of the machine on which the agent runs
	MachineHostName string `mapstructure:"host_name"`
	// Whether to run the server as a mock server (no FPGA access)
	MockServer bool `mapstructure:"mock_server"`
	// Do not start the Agent's API server
	NoAPI bool `mapstructure:"no_api"`
	// Disable loading configuration from the system keyring
	NoKeyring bool `mapstructure:"no_keyring"`
	// Do not make provisioning requests to the service (provisioning or decommissioning)
	NoProvision bool `mapstructure:"no_provision"`
	// Override the the wrapper script used for running and monitoring jobs on FPGA hosts
	RunJobWrapper string `mapstructure:"run_job_wrapper"`
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *ServeConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.APIHost, validation.When(cfg.NoAPI == false, validation.Required)),
		validation.Field(&cfg.APIKey, validation.Required, validation.Match(regexp.MustCompile(`^(?!.*\s)[!-~]+$`))),
		validation.Field(&cfg.APIPort, validation.When(cfg.NoAPI == false, validation.Required)),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.DefaultJobTimeout, validation.Required),
		validation.Field(&cfg.Host, validation.Required, is.URL),
		validation.Field(&cfg.MachineHostName, validation.Required),
		validation.Field(&cfg.MockServer),
		validation.Field(&cfg.NoAPI),
		validation.Field(&cfg.NoKeyring),
		validation.Field(&cfg.NoProvision),
		validation.Field(&cfg.Sandpit, validation.Required),
	)
}

func DefaultServeConfiguration() *ServeConfiguration {
	return &ServeConfiguration{

		APIHost: "localhost",

		APIPort: 8080,

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		DefaultJobTimeout: func() time.Duration {
			duration, _ := time.ParseDuration("5m")
			return duration
		}(),

		Host: "https://all.api.keil.arm.com",

		MachineHostName: func() string {
			hostname, _ := os.Hostname()
			return hostname
		}(),

		RunJobWrapper: "/usr/bin/run_afaas_job.sh",

		Sandpit: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", "sandpit")
			}
			return filepath.Join(home, ".config", "afaas", "sandpit")
		}(),
	}
}

// ValidateConfiguration defines the configuration for Validate command
type ValidateConfiguration struct {
	// The path to the FPGA manifest file
	ManifestFile string `mapstructure:"manifest_file"`
	// Whether the validation should also include the validation of the content itself (not just syntax)
	Content bool `mapstructure:"content"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *ValidateConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.ManifestFile, validation.Required),
		validation.Field(&cfg.Content),
	)
}

func DefaultValidateConfiguration() *ValidateConfiguration {
	return &ValidateConfiguration{

		Content: true,
	}
}

// InitConfiguration defines the configuration for Init command
type InitConfiguration struct {
	// The host of the FPGA service itself
	AFAASHost string `mapstructure:"afaas_service_host"`
	// The host to the payload store
	AFAASStoreHost string `mapstructure:"afaas_store_host"`
	// Comma separated list of payload owners accepted by this agent
	AFAASStorePayloadOwners string `mapstructure:"afaas_store_payload_owners"`
	// The public key used to verify the authenticity of payloads
	AFAASStorePublicKey string `mapstructure:"afaas_store_public_key"`
	// An API token for the agent to authenticate with the payload store
	AFAASStoreToken string `mapstructure:"afaas_store_token"`
	// An API token for the agent to authenticate with the FPGA service itself
	AFAASToken string `mapstructure:"afaas_service_token"`
	// An API token to enforce authorisation when communicating with the agent via the API server
	AgentAPIToken string `mapstructure:"agent_api_token"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// the host name of the machine on which the agent runs
	MachineHostName string `mapstructure:"host_name"`
	// The path to the FPGA manifest file
	ManifestFile string `mapstructure:"manifest_file"`
	// Disable loading configuration from the system keyring
	NoKeyring bool `mapstructure:"no_keyring"`
	// Do not make provisioning requests to the service (provisioning or decommissioning)
	NoProvision bool `mapstructure:"no_provision"`
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *InitConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.AFAASHost, validation.Required, is.URL),
		validation.Field(&cfg.AFAASStoreHost, validation.Required, is.URL),
		validation.Field(&cfg.AFAASStoreToken, validation.Required),
		validation.Field(&cfg.AFAASToken, validation.Required),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.MachineHostName, validation.Required),
		validation.Field(&cfg.ManifestFile, validation.Required),
		validation.Field(&cfg.NoKeyring),
		validation.Field(&cfg.NoProvision),
		validation.Field(&cfg.Sandpit, validation.Required),
	)
}

func DefaultInitConfiguration() *InitConfiguration {
	return &InitConfiguration{

		AFAASHost: "https://all.api.test.keil.arm.com",

		AFAASStorePayloadOwners: "fpga-payloads-api",

		AFAASStorePublicKey: "GfLHSQ8RMD90+FBRm7ugs/8QAFuZm8jVVs8kjBPXtvM=",

		AgentAPIToken: func() string { return rand.Text() }(),

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		MachineHostName: func() string {
			hostname, _ := os.Hostname()
			return hostname
		}(),

		Sandpit: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", "sandpit")
			}
			return filepath.Join(home, ".config", "afaas", "sandpit")
		}(),
	}
}

// CredentialsConfiguration defines the configuration for Credentials command
type CredentialsConfiguration struct {
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`
	// The host of the FPGA service itself
	AFAASHost string `mapstructure:"afaas_service_host"`
	// An API token for the agent to authenticate with the FPGA service itself
	AFAASToken string `mapstructure:"afaas_service_token"`
	// The host to the payload store
	AFAASStoreHost string `mapstructure:"afaas_store_host"`
	// An API token for the agent to authenticate with the payload store
	AFAASStoreToken string `mapstructure:"afaas_store_token"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// The public key used to verify the authenticity of payloads
	AFAASStorePublicKey string `mapstructure:"afaas_store_public_key"`
	// the host name of the machine on which the agent runs
	MachineHostName string `mapstructure:"host_name"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *CredentialsConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.Sandpit, validation.Required),
		validation.Field(&cfg.AFAASHost, validation.Required, is.URL),
		validation.Field(&cfg.AFAASToken, validation.Required),
		validation.Field(&cfg.AFAASStoreHost, validation.Required, is.URL),
		validation.Field(&cfg.AFAASStoreToken, validation.Required),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.MachineHostName, validation.Required),
	)
}

func DefaultCredentialsConfiguration() *CredentialsConfiguration {
	return &CredentialsConfiguration{

		Sandpit: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", "sandpit")
			}
			return filepath.Join(home, ".config", "afaas", "sandpit")
		}(),

		AFAASHost: "https://all.api.test.keil.arm.com",

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		AFAASStorePublicKey: "GfLHSQ8RMD90+FBRm7ugs/8QAFuZm8jVVs8kjBPXtvM=",

		MachineHostName: func() string {
			hostname, _ := os.Hostname()
			return hostname
		}(),
	}
}

// AFaaSCredentialsConfiguration defines the configuration for AFaaSCredentials command
type AFaaSCredentialsConfiguration struct {
	// An API key enabling the use of the online services
	APIKey string `mapstructure:"api_key"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// The host to use for accessing the online services
	Host string `mapstructure:"host"`
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *AFaaSCredentialsConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.APIKey, validation.Required, validation.Match(regexp.MustCompile(`^(?!.*\s)[!-~]+$`))),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.Host, validation.Required, is.URL),
		validation.Field(&cfg.Sandpit, validation.Required),
	)
}

func DefaultAFaaSCredentialsConfiguration() *AFaaSCredentialsConfiguration {
	return &AFaaSCredentialsConfiguration{

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		Host: "https://all.api.keil.arm.com",

		Sandpit: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", "sandpit")
			}
			return filepath.Join(home, ".config", "afaas", "sandpit")
		}(),
	}
}

// DecommissionConfiguration defines the configuration for Decommission command
type DecommissionConfiguration struct {
	// An API key enabling the use of the online services
	APIKey string `mapstructure:"api_key"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// The host to use for accessing the online services
	Host string `mapstructure:"host"`
	// Disable loading configuration from the system keyring
	NoKeyring bool `mapstructure:"no_keyring"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *DecommissionConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.APIKey, validation.Required, validation.Match(regexp.MustCompile(`^(?!.*\s)[!-~]+$`))),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.Host, validation.Required, is.URL),
		validation.Field(&cfg.NoKeyring),
	)
}

func DefaultDecommissionConfiguration() *DecommissionConfiguration {
	return &DecommissionConfiguration{

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		Host: "https://all.api.keil.arm.com",
	}
}
