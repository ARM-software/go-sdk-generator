package config

import (
	"crypto/rand"
	"os"
	"path/filepath"
	"time"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
)

// ServeConfiguration defines the configuration for Serve command
type ServeConfiguration struct {
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// Do not make provisioning requests to the service (provisioning or decommissioning)
	NoProvision bool `mapstructure:"no_provision"`
	// the host name of the machine on which the agent runs
	MachineHostName string `mapstructure:"host_name"`
	// Do not start the Agent's API server
	NoAPI bool `mapstructure:"no_api"`
	// The host to run the agent API on
	APIHost string `mapstructure:"api_host"`
	// The port to run the agent API on
	APIPort int `mapstructure:"api_port"`
	// The default timeout for jobs
	DefaultJobTimeout time.Duration `mapstructure:"default_job_timeout"`
	// Whether to run the server as a mock server (no FPGA access)
	MockServer bool `mapstructure:"mock_server"`
	// Override the the wrapper script used for running and monitoring jobs on FPGA hosts
	RunJobWrapper string `mapstructure:"run_job_wrapper"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *ServeConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.Sandpit, validation.Required),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.NoProvision),
		validation.Field(&cfg.MachineHostName, validation.Required),
		validation.Field(&cfg.NoAPI),
		validation.Field(&cfg.APIHost, validation.When(cfg.NoAPI == false, validation.Required)),
		validation.Field(&cfg.APIPort, validation.When(cfg.NoAPI == false, validation.Required)),
		validation.Field(&cfg.DefaultJobTimeout, validation.Required),
		validation.Field(&cfg.MockServer),
	)
}

func DefaultServeConfiguration() *ServeConfiguration {
	return &ServeConfiguration{

		Sandpit: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", "sandpit")
			}
			return filepath.Join(home, ".config", "afaas", "sandpit")
		}(),

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		MachineHostName: func() string {
			hostname, _ := os.Hostname()
			return hostname
		}(),

		APIHost: "localhost",

		APIPort: 8080,

		DefaultJobTimeout: func() time.Duration {
			duration, _ := time.ParseDuration("5m")
			return duration
		}(),

		RunJobWrapper: "/usr/bin/run_afaas_job.sh",
	}
}

// ValidateConfiguration defines the configuration for Validate command
type ValidateConfiguration struct {
	// The path to the FPGA manifest file
	ManifestFile string `mapstructure:"manifest_file"`
	// Whether the validation should also include the validation of the content itself (not just syntax)
	Content bool `mapstructure:"content"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *ValidateConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.ManifestFile, validation.Required),
		validation.Field(&cfg.Content),
	)
}

func DefaultValidateConfiguration() *ValidateConfiguration {
	return &ValidateConfiguration{

		Content: true,
	}
}

// InitConfiguration defines the configuration for Init command
type InitConfiguration struct {
	// An API token to enforce authorisation when communicating with the agent via the API server
	AgentAPIToken string `mapstructure:"agent_api_token"`
	// The path to the FPGA manifest file
	ManifestFile string `mapstructure:"manifest_file"`
	// The path to the directory where the Agent can store data/files/artefacts it needs to run
	Sandpit string `mapstructure:"sandpit"`
	// The host of the FPGA service itself
	AFAASHost string `mapstructure:"afaas_service_host"`
	// An API token for the agent to authenticate with the FPGA service itself
	AFAASToken string `mapstructure:"afaas_service_token"`
	// The host to the payload store
	AFAASStoreHost string `mapstructure:"afaas_store_host"`
	// An API token for the agent to authenticate with the payload store
	AFAASStoreToken string `mapstructure:"afaas_store_token"`
	// The public key used to verify the authenticity of payloads
	AFAASStorePublicKey string `mapstructure:"afaas_store_public_key"`
	// Comma separated list of payload owners accepted by this agent
	AFAASStorePayloadOwners string `mapstructure:"afaas_store_payload_owners"`
	// A path to a file that is used as persistent data storage for recording the state of the agent and its representation in AFaaS. If this file is deleted then the host will be treated as a new host in AFaaS.
	DataFile string `mapstructure:"local_data_store"`
	// Do not make provisioning requests to the service (provisioning or decommissioning)
	NoProvision bool `mapstructure:"no_provision"`
	// the host name of the machine on which the agent runs
	MachineHostName string `mapstructure:"host_name"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *InitConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.ManifestFile, validation.Required),
		validation.Field(&cfg.Sandpit, validation.Required),
		validation.Field(&cfg.AFAASHost, validation.Required, is.URL),
		validation.Field(&cfg.AFAASToken, validation.Required),
		validation.Field(&cfg.AFAASStoreHost, validation.Required, is.URL),
		validation.Field(&cfg.AFAASStoreToken, validation.Required),
		validation.Field(&cfg.DataFile, validation.Required),
		validation.Field(&cfg.NoProvision),
		validation.Field(&cfg.MachineHostName, validation.Required),
	)
}

func DefaultInitConfiguration() *InitConfiguration {
	return &InitConfiguration{

		AgentAPIToken: func() string { return rand.Text() }(),

		Sandpit: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", "sandpit")
			}
			return filepath.Join(home, ".config", "afaas", "sandpit")
		}(),

		AFAASHost: "https://all.api.test.keil.arm.com",

		AFAASStorePublicKey: "GfLHSQ8RMD90+FBRm7ugs/8QAFuZm8jVVs8kjBPXtvM=",

		AFAASStorePayloadOwners: "fpga-payloads-api",

		DataFile: func() string {
			home, err := os.UserHomeDir()
			if err != nil {
				return filepath.Join("afaas", ".afaas-agent.sqlite")
			}
			return filepath.Join(home, ".config", "afaas", ".afaas-agent.sqlite")
		}(),

		MachineHostName: func() string {
			hostname, _ := os.Hostname()
			return hostname
		}(),
	}
}

// DecommissionConfiguration defines the configuration for Decommission command
type DecommissionConfiguration struct {
	// The URL the FPGA agent API is running on
	APIurl string `mapstructure:"api_url"`
	// The token used to authenticate with the FPGA agent API
	APIToken string `mapstructure:"api_token"`

	// ToolVersion contains the version of the CLI tool
	ToolVersion *string
}

func (cfg *DecommissionConfiguration) Validate() error {
	err := configUtils.ValidateEmbedded(cfg)
	if err != nil {
		return err
	}

	return validation.ValidateStruct(cfg,
		validation.Field(&cfg.APIurl, is.URL),
	)
}

func DefaultDecommissionConfiguration() *DecommissionConfiguration {
	return &DecommissionConfiguration{

		APIurl: "http://localhost:8080",
	}
}
