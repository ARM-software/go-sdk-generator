package cmd

import (
	"context"
	"embed"
	"os"

	configUtils "github.com/ARM-software/golang-utils/utils/config"
	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/charmbracelet/fang"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"

	"github.com/Arm-Debug/fpga-service-agent/cli/cmd/config"
)

const (
	rootAPIKeyArg = "api-key" //nolint:gosec // not a secret
	rootHostArg   = "host"
)

var (
	//go:embed module.properties
	embeddedFS   embed.FS
	viperSession = viper.New()
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "fpga-service-agent",
	Short: "CLI to control the FPGA service agent",
	Long:  "CLI to control the FPGA service agent",
}

func Execute() {
	ctx := context.Background()

	cliVersion, err := semver.DetermineEmbeddedVersion(ctx, &embeddedFS, nil)
	if err != nil {
		// This is for completeness but it is impossible at runtime since we need a valid module.properties in this location to release the package
		cliVersion = "unknown"
	}

	if err := fang.Execute(ctx, rootCmd, fang.WithVersion(cliVersion)); err != nil {

		os.Exit(1)
	}
}

func init() {
	rootCmd.PersistentFlags().StringP(rootAPIKeyArg, "k", "", "An API key enabling the use of the online services")
	rootCmd.PersistentFlags().String(rootHostArg, "", "The host to use for accessing the online services")

	_ = configUtils.BindFlagToEnv(viperSession, config.App, "api_key", rootCmd.PersistentFlags().Lookup(rootAPIKeyArg))
	_ = configUtils.BindFlagToEnv(viperSession, config.App, "host", rootCmd.PersistentFlags().Lookup(rootHostArg))
}
