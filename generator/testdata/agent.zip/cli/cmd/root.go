package cmd

import (
	"context"
	"embed"
	"os"

	"github.com/ARM-software/golang-utils/utils/semver"
	"github.com/charmbracelet/fang"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var (
	//go:embed module.properties
	embeddedFS   embed.FS
	viperSession = viper.New()
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "fpga-service-agent",
	Short: "CLI to control the FPGA service agent",
	Long:  "CLI to control the FPGA service agent",
}

func Execute() {
	ctx := context.Background()

	cliVersion, err := semver.DetermineEmbeddedVersion(ctx, &embeddedFS, nil)
	if err != nil {
		// This is for completeness but it is impossible at runtime since we need a valid module.properties in this location to release the package
		cliVersion = "unknown"
	}

	if err := fang.Execute(ctx, rootCmd, fang.WithVersion(cliVersion)); err != nil {

		os.Exit(1)
	}
}

func init() {

}
