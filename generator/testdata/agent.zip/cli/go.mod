module github.com/Arm-Debug/fpga-service-agent/cli

go 1.24.6

toolchain go1.24.6

replace github.com/Arm-Debug/fpga-service-agent/agent => ../agent

