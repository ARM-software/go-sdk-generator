package main

import "github.com/Arm-Debug/fpga-service-agent/cli/cmd"

func main() {
	cmd.Execute()
}
